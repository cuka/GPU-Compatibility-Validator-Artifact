"""Public, replayable per-invocation context, challenge and arithmetic."""

import hashlib
import struct

from .contracts import AuditError, canonical

MODULUS = 65521
PARAMETERS_A = (17, 29, 13, 7)
PARAMETERS_B = (19, 31, 11, 5)


def make_context(payload):
    return hashlib.sha256(b"compute_audit.context.v3\0" + canonical(payload)).digest()


def derive_challenge(context, length=32):
    if len(context) != 32 or type(length) is not int or length < 2:
        raise AuditError("CHALLENGE_PARAMETERS_INVALID")
    prefix = b"compute_audit.challenge.word.v3\0" + context
    for retry in range(16):
        values = []
        for index in range(length):
            word = hashlib.sha256(prefix + struct.pack(">QQ", retry, index)).digest()
            values.append(int.from_bytes(word[:8], "big") % MODULUS)
        if len(set(values)) > 1:
            return values, retry
    raise AuditError("CHALLENGE_GENERATION_ERROR")


def normalized_parameters(parameters):
    if len(parameters) != 4:
        raise AuditError("CONSTANT_MISMATCH")
    return tuple(int(value) % MODULUS for value in parameters)


def make_message(parameters, context):
    if len(context) != 32:
        raise AuditError("CONTEXT_LENGTH_INVALID")
    return b"CAV3" + struct.pack(">4I", *normalized_parameters(parameters)) + context


def decode_message(message, context, parameters=None):
    if len(message) != 52 or message[:4] != b"CAV3":
        raise AuditError("MESSAGE_FORMAT_ERROR")
    if message[20:] != context:
        raise AuditError("CONTEXT_MISMATCH")
    values = struct.unpack(">4I", message[4:20])
    if max(values) >= MODULUS or not values[0] or not values[2]:
        raise AuditError("CONSTANT_MISMATCH")
    if parameters is not None and values != normalized_parameters(parameters):
        raise AuditError("CONSTANT_MISMATCH")
    return values


def compute_challenge(values, parameters):
    a, b, c, d = normalized_parameters(parameters)
    return [(((int(x) % MODULUS * a + b) % MODULUS) * c + d) % MODULUS for x in values]
