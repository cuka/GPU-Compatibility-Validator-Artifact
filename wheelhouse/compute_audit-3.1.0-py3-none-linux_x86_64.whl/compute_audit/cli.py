"""Public CLI for probes, runs and independent reviews."""

import argparse
import os
import sys
import tempfile
from contextlib import ExitStack, contextmanager, redirect_stderr, redirect_stdout
from importlib.util import find_spec
from pathlib import Path

import numpy as np

from .config import GENERAL, catalog_digest, profile_from
from .contracts import AuditError, Exit, load, write
from .inventory import select, snapshot
from .operators import make_inputs
from .probe import probe
from .reference import compare, reference
from .runner import run


class AuditParser(argparse.ArgumentParser):
    def error(self, _message):
        self.print_usage(sys.stderr)
        self.exit(2, "Invalid command arguments.\n")


@contextmanager
def _quiet_execution():
    """Keep subprocess and native diagnostics out of public output."""
    with open(os.devnull, "w", encoding="utf-8") as sink, ExitStack() as stack:
        for stream, fd in ((sys.stdout, 1), (sys.stderr, 2)):
            stream.flush()
            original = os.dup(fd)
            stack.callback(os.close, original)
            stack.callback(os.dup2, original, fd)
            os.dup2(sink.fileno(), fd)
        stack.enter_context(redirect_stdout(sink))
        stack.enter_context(redirect_stderr(sink))
        yield


def _run_args(parser):
    parser.add_argument("--profile", help="Run profile (default: profiles/conformance.json)")
    parser.add_argument("--devices", default="all-visible")
    parser.add_argument("--inventory")
    parser.add_argument("--expect-inventory-sha256")
    parser.add_argument("--expect-profile-sha256")
    parser.add_argument("--expect-release-sha256")
    parser.add_argument("--run-id")
    parser.add_argument("--run-context")
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument("--plan-registration")
    parser.add_argument("--parameters")
    parser.add_argument("--private-evidence", help="Directory for restricted evidence (temporary by default)")
    parser.add_argument("--output", required=True)


def _review_args(parser):
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--expect-profile-sha256")
    parser.add_argument("--expect-inventory-sha256")
    parser.add_argument("--expect-release-sha256")
    parser.add_argument("--expect-run-id")
    parser.add_argument("--run-context")
    parser.add_argument("--receipt")
    parser.add_argument("--private-evidence", help="Directory containing restricted evidence")
    parser.add_argument("--output", required=True)
    if find_spec("compute_audit.field_replay") is not None:
        parser.add_argument("--audit-inventory", help="Independently maintained inventory for full review")
        parser.add_argument("--approved-inventory", help="Original approved inventory for acceptance review")


def parser():
    program = AuditParser(prog="compute-audit")
    program.add_argument("--version", action="version", version="compute-audit 3.1.0")
    commands = program.add_subparsers(dest="command", required=True)
    command = commands.add_parser("probe")
    command.add_argument("--private-evidence", help="Directory for the full restricted environment probe")
    command.add_argument("--output", required=True)
    command = commands.add_parser("inventory")
    command.add_argument("--scope", choices=("physical", "visible", "explicit"), default="physical")
    command.add_argument("--devices")
    command.add_argument("--private-evidence", help="Directory for the full restricted device inventory")
    command.add_argument("--output", required=True)
    _run_args(commands.add_parser("run"))
    _run_args(commands.add_parser("selftest"))
    command = commands.add_parser("verify-bundle")
    _review_args(command)
    group = command.add_mutually_exclusive_group()
    group.add_argument("--require-acceptance", action="store_true")
    group.add_argument("--integrity-only", action="store_true")
    command = commands.add_parser("replay")
    _review_args(command)
    command.add_argument("--mode", choices=("reference", "device"), required=True)
    command.add_argument("--devices", default="all-visible")
    command.add_argument("--parameters")
    command.add_argument("--private-evidence-output", help="Directory for restricted evidence from the replay")
    commands.add_parser("catalog-digest")
    return program


def _smoke(args, profile):
    cases = []
    for operator, names in GENERAL.items():
        for name in names:
            values, parameters = make_inputs(name, profile["seed"], profile["rmsnorm_eps"])
            expected = reference(name, values, parameters, profile["reference_block_query_rows"])
            _, counts, verdict = compare(expected, expected, 0, 0, profile["relative_floor"])
            cases.append({"operator": operator, "case_id": name, "status": "PASS" if not verdict else "FAIL", "counts": counts.tolist()})
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    passed = all(case["status"] == "PASS" for case in cases)
    code = Exit.PASS if passed else Exit.FAIL
    write(output / "report.json", {"schema_version": "3.0", "report_kind": "run", "scope": "smoke", "execution_mode": "cpu_reference",
                                  "acceptance_eligible": False, "declared_run_status": code.name, "gpu_status": "NOT_RUN", "cases": cases})
    print(f"{code.name}  {output / 'report.json'}")
    return code


def _separate_outputs(public, private):
    if public.is_relative_to(private) or private.is_relative_to(public):
        raise AuditError("RESULT_DIRECTORIES_OVERLAP")


def _private_document(args, filename, value):
    if args.private_evidence:
        private = Path(args.private_evidence).resolve()
        _separate_outputs(Path(args.output).resolve(), private)
        private.mkdir(parents=True, exist_ok=False, mode=0o700)
        write(private / filename, value)


def _public_run(args, profile, *, selftest=False):
    from .public_results import publish

    destination = Path(args.output).resolve()
    if destination.exists():
        raise AuditError("OUTPUT_ALREADY_EXISTS")
    if (profile["scope"] == "acceptance" or args.plan_only) and not args.private_evidence:
        raise AuditError("PRIVATE_EVIDENCE_REQUIRED")
    with tempfile.TemporaryDirectory(prefix="compute-audit-") as temporary:
        private = Path(args.private_evidence or Path(temporary) / "evidence").resolve()
        _separate_outputs(destination, private)
        code = run(argparse.Namespace(**(vars(args) | {"output": private})), profile, selftest=selftest)
        if args.plan_only and code == Exit.PASS:
            destination.mkdir(parents=True, exist_ok=False)
            write(destination / "report.json", {"report_kind": "plan_only", "status": "READY", "acceptance_eligible": False})
        else:
            publish(private, destination, code)
    return code


def _review(args, *, replay=False):
    from .public_results import assert_public_matches, project_verification, verify_public

    bundle = Path(args.bundle).resolve()
    out = Path(args.output).resolve()
    if out.is_relative_to(bundle):
        raise AuditError("VERIFICATION_OUTPUT_MUST_BE_EXTERNAL")
    public = load(bundle / "report.json").get("report_kind") == "public_run"
    private = Path(args.private_evidence).resolve() if args.private_evidence else None
    if public:
        summary = verify_public(bundle)
        if private is None:
            if replay:
                raise AuditError("PRIVATE_EVIDENCE_REQUIRED")
            code = Exit[summary["declared_run_status"]]
            if args.require_acceptance and code == Exit.PASS:
                code = Exit.INCOMPLETE
            write(out, summary | {"final_status": code.name})
            return Exit.PASS if args.integrity_only else code
        _separate_outputs(bundle, private)
        assert_public_matches(bundle, private)
    elif private is not None:
        raise AuditError("PRIVATE_EVIDENCE_REQUIRES_PUBLIC_BUNDLE")
    else:
        private = bundle
    if out.is_relative_to(private):
        raise AuditError("VERIFICATION_OUTPUT_MUST_BE_EXTERNAL")
    with tempfile.TemporaryDirectory(prefix="compute-audit-review-") as temporary:
        options = argparse.Namespace(**(vars(args) | {"output": Path(temporary) / "review.json", "bundle": private}))
        code = verify(options, replay=replay)
        write(out, project_verification(load(options.output)))
    return code


def verify(args, *, replay=False):
    plan = load(Path(args.bundle) / "plan.json")
    if plan.get("validator_abi") == "3.1" and not getattr(args, "audit_inventory", None):
        from .field_verifier import verify as review
    elif find_spec("compute_audit.replay") is not None:
        from .replay import verify as review
    else:
        raise AuditError("REVIEW_MATERIAL_UNAVAILABLE")
    return review(args, replay=replay)


def _dispatch(args):
    if args.command == "probe":
        full = probe()
        state = full["topology"]
        _private_document(args, "probe.json", full)
        write(args.output, {"schema_version": "3.0", "report_kind": "probe", "acceptance_eligible": False,
                            "physical_devices": len(state["physical"]), "visible_devices": len(state["visible"])})
        return Exit.PASS
    if args.command == "inventory":
        state = snapshot()
        request = {"physical": "all", "visible": "all-visible", "explicit": args.devices}[args.scope]
        if request is None:
            raise AuditError("EXPLICIT_DEVICES_REQUIRED")
        targets = select(state, request)
        _private_document(args, "inventory.json", {"schema_version": "3.0", "scope": args.scope, "host": state["host"], "targets": targets})
        public = [{"target_id": f"GPU-{number}"} for number, _ in enumerate(targets, 1)]
        write(args.output, {"schema_version": "3.0", "scope": args.scope, "targets": public})
        return Exit.PASS if targets else Exit.UNSUPPORTED
    if args.command in {"run", "selftest"}:
        selftest = args.command == "selftest"
        if args.profile is None:
            release = Path(os.getenv("COMPUTE_AUDIT_RELEASE_DIR", "."))
            args.profile = str(release / "profiles/conformance.json")
        profile = profile_from(args.profile)
        if selftest and profile["scope"] != "conformance":
            raise AuditError("SELFTEST_CONFORMANCE_PROFILE_REQUIRED")
        if profile["scope"] == "smoke":
            return _smoke(args, profile)
        return _public_run(args, profile, selftest=selftest)
    if args.command == "verify-bundle":
        return _review(args)
    args.require_acceptance = args.integrity_only = False
    if args.mode == "reference":
        return _review(args, replay=True)
    return _device_replay(args)


def _device_replay(args):
    from .public_results import assert_public_matches, verify_public

    root = Path(args.bundle).resolve()
    out = Path(args.output).resolve()
    if out.is_relative_to(root):
        raise AuditError("REPLAY_OUTPUT_MUST_BE_EXTERNAL")
    if load(root / "report.json").get("report_kind") == "public_run":
        if not args.private_evidence:
            raise AuditError("PRIVATE_EVIDENCE_REQUIRED")
        private = Path(args.private_evidence).resolve()
        _separate_outputs(root, private)
        verify_public(root)
        assert_public_matches(root, private)
        root = private
    if out.is_relative_to(root):
        raise AuditError("REPLAY_OUTPUT_MUST_BE_EXTERNAL")
    if args.private_evidence_output:
        _separate_outputs(Path(args.bundle).resolve(), Path(args.private_evidence_output).resolve())
        _separate_outputs(root, Path(args.private_evidence_output).resolve())
    with tempfile.TemporaryDirectory() as temporary:
        options = argparse.Namespace(**vars(args))
        options.bundle = root
        options.output = str(Path(temporary) / "reference.json")
        verify(options, replay=True)
        source = load(root / "plan.json")
        profile = load(root / "profile.json") | {"profile_id": "device_replay_v3", "profile_status": "development", "scope": "conformance",
                                               "device_selection": {"mode": "all_visible"}, "native_sha256": None, "parameters_sha256": None}
        args.profile = str(Path(temporary) / "profile.json")
        write(args.profile, profile)
        args.inventory = args.run_id = args.run_context = None
        args.expect_profile_sha256 = args.expect_inventory_sha256 = None
        args.plan_only = False
        args.plan_registration = None
        if not os.getenv("COMPUTE_AUDIT_RELEASE_DIR"):
            args.parameters = args.parameters or root / "parameters/parameters.json"
        args.private_evidence = args.private_evidence_output
        args.replay_source, args.source_run_id = str(root), source["run_id"]
        return _public_run(args, profile_from(args.profile), selftest=source["selftest"])


def main(argv=None):
    args = parser().parse_args(argv)
    if args.command == "catalog-digest":
        print(catalog_digest())
        return int(Exit.PASS)
    try:
        with _quiet_execution():
            code = _dispatch(args)
        print("READY" if getattr(args, "plan_only", False) and code == Exit.PASS else code.name)
        if args.command in {"run", "selftest"} or (args.command == "replay" and args.mode == "device"):
            report = load(Path(args.output) / "report.json")
            if report.get("report_kind") == "public_run":
                for row in report["devices"]:
                    validation = row["operators"]["Validate Compute"]
                    if validation["status"] in {"ERROR", "FAIL"}:
                        print(f"GPU-{row['gpu']}  Validate Compute  Execution failed")
        return int(code)
    except KeyboardInterrupt:
        print("INCOMPLETE", file=sys.stderr)
        return int(Exit.INCOMPLETE)
    except Exception:
        print("Execution failed", file=sys.stderr)
        if args.command == "verify-bundle":
            try:
                output = Path(args.output).resolve()
                protected = [Path(path).resolve() for path in (args.bundle, args.private_evidence) if path]
                if not any(output.is_relative_to(root) for root in protected):
                    write(output, {"schema_version": "3.0", "report_kind": "verify", "verification_status": "ERROR", "final_status": "ERROR",
                                   "acceptance_eligible": False})
            except (OSError, RuntimeError):
                pass
        return int(Exit.ERROR)
