"""Shared serialization, safe paths and public statuses."""

import hashlib
import json
import re
from enum import IntEnum
from pathlib import Path


class Exit(IntEnum):
    PASS = 0
    INCOMPLETE = 10
    FAIL = 20
    ERROR = 30
    UNSUPPORTED = 40


class AuditError(ValueError):
    """An input, contract or evidence error."""


CASE_STATES = {"PASS", "FAIL", "UNSUPPORTED", "RESOURCE_LIMIT", "SKIPPED", "ERROR"}
NUMERIC = ("PASS", "NUMERIC_MISMATCH", "EMPTY", "INVALID_REFERENCE", "CHECKER_ARITHMETIC_ERROR")


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise AuditError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _invalid_constant(value):
    raise AuditError(f"non-finite JSON constant: {value}")


def parse(raw):
    value = json.loads(raw, object_pairs_hook=_object, parse_constant=_invalid_constant)
    canonical(value)  # Also rejects overflowed exponents such as 1e999.
    return value


def load(path):
    return parse(Path(path).read_bytes())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".partial")
    temporary.write_bytes(canonical(value) + b"\n")
    temporary.replace(path)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    with Path(path).open("rb") as stream:
        hasher = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def safe_path(root, name):
    if not isinstance(name, str) or "\\" in name or any(part in ("", ".", "..") for part in name.split("/")):
        raise AuditError(f"invalid relative path: {name!r}")
    root = Path(root).resolve()
    path = root
    for part in name.split("/"):
        path /= part
        if path.is_symlink():
            raise AuditError(f"symlink is not evidence: {name}")
    return path


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", value):
        raise AuditError(f"invalid identifier: {value!r}")
    return value


def aggregate(records, *, evidence_error=False, incomplete=False, allow_unsupported=True):
    required = [row for row in records if row["required"]]
    states = {row["status"] for row in required}
    if not required or evidence_error or states - CASE_STATES:
        return Exit.ERROR
    if "FAIL" in states:
        return Exit.FAIL
    if "ERROR" in states:
        return Exit.ERROR
    if allow_unsupported and states == {"UNSUPPORTED"}:
        return Exit.UNSUPPORTED
    return Exit.PASS if states == {"PASS"} and not incomplete else Exit.INCOMPLETE
