"""Physical host identities and (independent) runtime device mappings."""

import ctypes
import ctypes.util
import glob
import os
import re
import shutil
import socket
import subprocess
from pathlib import Path

from .contracts import AuditError, identifier


PCI = re.compile(r"^(?:[0-9a-f]{4}:)?[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]$", re.I)
VISIBILITY = ("ROCR_VISIBLE_DEVICES", "HIP_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES", "GPU_DEVICE_ORDINAL")


def pci_id(value):
    value = str(value).lower()
    if not PCI.fullmatch(value):
        raise AuditError(f"DEVICE_PCI_INVALID: {value}")
    return value if len(value) == 12 else f"0000:{value}"


def _run(*args):
    try:
        completed = subprocess.run(args, text=True, capture_output=True, timeout=12, check=False)
        return completed.stdout if completed.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _management_cards():
    if not shutil.which("hy-smi"):
        return {}
    output = _run("hy-smi", "--showbus", "--showproductname")
    rows = {}
    for line in output.splitlines():
        match = re.search(r"(?:DCU|GPU)\[([0-9]+)\]\s*:\s*([^:]+):\s*(.+)$", line, re.I)
        if not match:
            continue
        logical, field, value = match.groups()
        value = value.strip()
        if value.lower() in {"n/a", "unknown", "unsupported", "none", "0", "0x0"}:
            continue
        key = {"pci bus": "pci_bus_id", "card series": "model"}.get(field.strip().lower())
        if key:
            rows.setdefault(logical, {})[key] = pci_id(value) if key == "pci_bus_id" else value
    return {row["pci_bus_id"]: row for row in rows.values() if "pci_bus_id" in row}


def _runtime_pci(index, properties):
    property_bus = getattr(properties, "pci_bus_id", None)
    if isinstance(property_bus, str) and PCI.fullmatch(property_bus):
        return pci_id(property_bus)
    domain = getattr(properties, "pci_domain_id", None)
    slot = getattr(properties, "pci_device_id", None)
    if all(type(value) is int for value in (domain, property_bus, slot)) and 0 <= domain <= 65535 and 0 <= property_bus <= 255 and 0 <= slot <= 31:
        candidates = list(Path("/sys/bus/pci/devices").glob(f"{domain:04x}:{property_bus:02x}:{slot:02x}.*"))
        if len(candidates) == 1:
            return pci_id(candidates[0].name)
    for name in ("libamdhip64.so", ctypes.util.find_library("amdhip64"), "libcudart.so", ctypes.util.find_library("cudart")):
        if not name:
            continue
        try:
            library = ctypes.CDLL(name)
            get_bus = getattr(library, "hipDeviceGetPCIBusId", None) or library.cudaDeviceGetPCIBusId
            get_bus.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
            get_bus.restype = ctypes.c_int
            buffer = ctypes.create_string_buffer(32)
            if get_bus(buffer, len(buffer), index) == 0:
                return pci_id(buffer.value.decode("ascii"))
        except (OSError, AttributeError, ValueError):
            continue
    return None


def runtime_devices():
    try:
        import torch
    except ImportError:
        return [], {"torch": None, "runtime_error": "PYTORCH_NOT_INSTALLED"}
    meta = {"torch": torch.__version__, "torch_path": torch.__file__, "hip": getattr(torch.version, "hip", None),
            "cuda": getattr(torch.version, "cuda", None), "cxx11_abi": getattr(torch._C, "_GLIBCXX_USE_CXX11_ABI", None)}
    items = []
    try:
        for index in range(torch.cuda.device_count()):
            properties = torch.cuda.get_device_properties(index)
            items.append({"runtime_index": index, "pci_bus_id": _runtime_pci(index, properties),
                          "runtime_name": properties.name, "memory_bytes": int(properties.total_memory),
                          "architecture": getattr(properties, "gcnArchName", None)})
    except (OSError, RuntimeError):
        meta["runtime_error"] = "RUNTIME_QUERY_FAILED"
    return items, meta


def snapshot():
    physical = _management_cards()
    for device in glob.glob("/sys/bus/pci/devices/*"):
        path = Path(device)
        try:
            if (path / "vendor").read_text().strip() != "0x1d94" or not (path / "class").read_text().strip().startswith(("0x03", "0x0b40")):
                continue
        except OSError:
            continue
        bus = pci_id(path.name)
        physical.setdefault(bus, {"pci_bus_id": bus})
    visible, runtime = runtime_devices()
    for row in visible:
        bus = row["pci_bus_id"]
        if bus and bus not in physical:
            physical[bus] = {"pci_bus_id": bus, "discovery": "runtime"}
    return {"schema_version": "3.0", "host": socket.gethostname(), "physical": [physical[key] for key in sorted(physical)],
            "visible": visible, "visibility": {key: os.environ.get(key) for key in VISIBILITY}, "runtime": runtime,
            "device_nodes": {p: os.access(p, os.R_OK | os.W_OK) for p in ["/dev/kfd", *sorted(glob.glob("/dev/dri/renderD*"))] if os.path.exists(p)},
            "container_indicators": [p for p in ("/.dockerenv", "/run/.containerenv") if os.path.exists(p)]}


def select(snapshot_data, selection):
    visible = snapshot_data["visible"]
    physical = {row["pci_bus_id"]: row for row in snapshot_data["physical"]}
    mapping = {row["pci_bus_id"]: row["runtime_index"] for row in visible if row["pci_bus_id"]}
    if selection == "all":
        return [{**row, "target_id": f"GPU-{i}", "runtime_index": mapping.get(bus)}
                for i, (bus, row) in enumerate(sorted(physical.items()))]
    requested = None if selection == "all-visible" else set(selection.split(","))
    result = []
    found = set()
    for dev in visible:
        bus, index = dev["pci_bus_id"], dev["runtime_index"]
        keys = {str(index), bus}
        if requested is None or keys & requested:
            found.update(keys)
            result.append({**physical.get(bus, {}), **dev, "target_id": f"GPU-{index}"})
    if requested and requested - found:
        raise AuditError(f"DEVICE_SELECTION_MISSING: {sorted(requested - found)}")
    return result


def read_targets(data, *, field=False):
    if data.get("schema_version") != "3.0" or not isinstance(data.get("targets"), list):
        raise AuditError("INVENTORY_SCHEMA_INVALID")
    used_ids, used_buses = set(), set()
    targets = []
    for row in data["targets"]:
        name = identifier(row["target_id"])
        bus = pci_id(row["pci_bus_id"]) if row.get("pci_bus_id") else None
        if name in used_ids or (bus and bus in used_buses):
            raise AuditError("INVENTORY_MAPPING_CONFLICT")
        used_ids.add(name)
        if bus:
            used_buses.add(bus)
        targets.append({"target_id": f"GPU-{len(targets) + 1}", "pci_bus_id": bus} if field else row)
    return targets


def match_target(target, observed):
    bus = target.get("pci_bus_id")
    matches = [row for row in observed["visible"] if bus is not None and row["pci_bus_id"] == bus]
    if len(matches) != 1:
        return None, "DEVICE_MAPPING_MISSING" if not matches else "DEVICE_MAPPING_CONFLICT"
    return matches[0], None
