"""Independent host checks for numerical results and execution evidence."""

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .artifacts import check_manifest, event_hash, read_jsonl, read_tensor
from .challenge import PARAMETERS_B, compute_challenge, derive_challenge, make_context
from .config import normalize_profile, tolerance
from .contracts import AuditError, CASE_STATES, Exit, aggregate, canonical, digest, file_digest, load, safe_path, write
from .kineto_binding import validate_binding
from .kineto_copy import G4_SHAPES, validate_g4_copy
from .operators import make_inputs
from .reference import compare, numeric_vector, reference
from .validate_op import NATIVE_ROLES


FP64_PROBE_INPUT = (1.0000000000000002, 1., 7., 3., 4., 1e-12)


def check_fp64_probe(root, capability, limit):
    if capability == {"status": "FP64_PROBE_FAILED", "activities": []}:
        return "FP64_PROBE_FAILED"
    src = read_tensor(root, capability["input"], limit)
    result = read_tensor(root, capability["output"], limit)
    if src.dtype != np.float64 or not np.array_equal(src, FP64_PROBE_INPUT):
        raise AuditError("FP64_PROBE_INPUT_OR_OUTPUT_INVALID")
    if result.dtype != np.float64 or result.shape != (5,):
        return "FP64_PROBE_CONTRACT_INVALID"
    a, b, c, d, e, f = src
    expected = np.array([a - b, a + b, c / d, e * f, np.sqrt(f)], dtype=np.float64)
    if not any(activity["role"] == "fp64_probe" for activity in capability["activities"]):
        return "MISSING_EVIDENCE"
    return "PASS" if np.allclose(result, expected, rtol=1e-12, atol=0) else "FP64_ARITHMETIC_UNSUPPORTED"


def dynamic_input(plan, case, invocation, inputs, parameters):
    sample = invocation["sample_id"]
    invocation_id = invocation["invocation_id"]
    shared = {"C2": ("check-3", "check-1"), "C6": ("check-1", "check-0")}.get(case["case_id"])
    if shared and sample == shared[0]:
        sample = shared[1]
        invocation_id = invocation_id.removesuffix(shared[0]) + sample
    base = digest(canonical({"inputs": inputs, "parameters": plan["parameters"]}))
    payload = {"run_id": plan["run_id"], "run_nonce": plan["run_nonce"], "target_id": case["target_id"],
               "case_id": case["case_id"], "attempt_id": invocation["attempt_id"], "sample_id": sample,
               "invocation_id": invocation_id, "plan_sha256": plan["plan_sha256"],
               "base_input_sha256": base, "validator_abi": plan["validator_abi"]}
    context = make_context(payload)
    values, retry = derive_challenge(context, plan["challenge_length"])
    return {"context_hex": context.hex(), "challenge": list(values), "challenge_retry": retry, "parameters": parameters}


@dataclass
class NumericalResult:
    metrics: np.ndarray | None
    counts: np.ndarray | None
    verdict: int | None
    math_status: str
    reference_ok: bool


def _quantized_inputs(root, profile, plan, case, row):
    limit = profile["max_host_working_bytes"]
    actual = {name: read_tensor(root, meta, limit) for name, meta in row["inputs"].items()}
    if not plan.get("source_run_id"):
        expected, args = make_inputs(case["case_id"], profile["seed"], profile["rmsnorm_eps"])
        if args != row["operator_args"] or expected.keys() != actual.keys():
            raise AuditError("OPERATOR_INPUT_CONTRACT_INVALID")
        for name, data in expected.items():
            dtype = "bool" if data.dtype == np.bool_ else case["dtype"]
            if row["inputs"][name]["dtype"] != dtype:
                raise AuditError("OPERATOR_INPUT_CONTRACT_INVALID")
            if dtype == "bfloat16":
                bits = data.view(np.uint32)
                rounded = (bits + np.uint32(0x7fff) + ((bits >> 16) & 1)) & np.uint32(0xffff0000)
                value = np.where(np.isnan(data), np.nan, rounded.view(np.float32))
            else:
                value = data.astype(dtype)
            if not np.array_equal(value, actual[name], equal_nan=True):
                raise AuditError("OPERATOR_INPUT_QUANTIZATION_MISMATCH")
    return actual


def _evaluate_math(root, profile, plan, case, row):
    limit = profile["max_host_working_bytes"]
    case_id = case["case_id"]
    if case["dtype"]:
        inputs = _quantized_inputs(root, profile, plan, case, row)
        a = read_tensor(root, row["actual"], limit)
        b = reference(case_id, inputs, row["operator_args"], profile["reference_block_query_rows"])
        described = {"tensors": row["inputs"], "math": row["operator_args"]}
        atol, rtol = tolerance(profile, case)
        expected_verdict = 0
    else:
        described = {"tensors": row["inputs"], "case_id": case_id}
        a, b, atol, expected_verdict = numeric_vector(case_id) if case_id.startswith("V") else ([1.], [1.], 0., 0)
        rtol = 0.
    if row["base_input"] != described:
        raise AuditError("BASE_INPUT_BINDING_MISMATCH")
    uploaded = read_tensor(root, row["reference"], limit)
    reference_ok = np.array_equal(uploaded, np.asarray(b), equal_nan=True)
    if case["dtype"] and (row["actual"]["dtype"] != case["dtype"] or a.shape != b.shape
                          or row["actual"]["device"] != row["device"]):
        return NumericalResult(None, None, None, "FAIL", reference_ok)
    metrics, counts, verdict = compare(a, b, atol, rtol, profile["relative_floor"])
    status = "PASS" if verdict == expected_verdict else "FAIL" if verdict == 1 else "ERROR"
    return NumericalResult(metrics, counts, verdict, status, reference_ok)


def invocation_coordinates(row):
    if not row["case_id"].startswith("C"):
        return 1, 0
    return int(row["case_id"][1:]), int(row["sample_id"].split("-")[1])


def _output_checks(root, profile, plan, case, row, numeric):
    group, item = invocation_coordinates(row)
    fields = row["validation_input"]
    expected_parameters = list(PARAMETERS_B) if (group, item) == (6, 1) else plan["parameters"]
    expected = dynamic_input(plan, case, row, row["base_input"], expected_parameters)
    nonce = bytes.fromhex(fields["nonce_hex"])
    if (fields != expected | {"nonce_hex": nonce.hex()} or len(nonce) != 32
            or ((group, item) == (1, 0) and case["case_id"] == "C1"
                and nonce != fixed_nonce(fields))):
        raise AuditError("INVOCATION_INPUT_MISMATCH")
    core = row["invocation_type"] == "core"
    challenge = fields["challenge"]
    challenge_output = compute_challenge(challenge, expected_parameters) if core or group == 6 else (
        [-1] * len(challenge) if group == 5 and item >= 5 else [])
    contract = {"challenge_output": ("int64", [len(challenge_output)]), "status": ("int64", []), "witness": ("uint8", [32])}
    if core:
        contract.update(metrics=("float64", [4]), counts=("int64", [9]), numeric_verdict=("int64", []))
    if {name: (meta["dtype"], meta["shape"]) for name, meta in row["outputs"].items()} != contract:
        raise AuditError("NATIVE_OUTPUT_CONTRACT_INVALID")
    outputs = {name: read_tensor(root, meta, profile["max_host_working_bytes"]) for name, meta in row["outputs"].items()}
    status = int(outputs["status"].item())
    if status not in (0, 1):
        raise AuditError("NATIVE_OUTPUT_CONTRACT_INVALID")
    if status or outputs["challenge_output"].tolist() != challenge_output or not outputs["witness"].any():
        return "FAIL", "VALIDATOR_FAILED"
    observed = {activity["role"] for activity in row["activities"]}
    if core:
        if not numeric.reference_ok or numeric.counts is None:
            return "ERROR", "REFERENCE_DISAGREEMENT"
        skip_device_fp64 = plan.get("skip_device_fp64", False)
        needed = {"initialize"} if skip_device_fp64 or numeric.counts[0] == 0 else {"compare", "reduce"}
        needed |= {f"stage_{name}" for name in "abcdef"}
        fp64 = row["binding"]["fp64_capability"]
        if skip_device_fp64:
            if (fp64 is not None or observed & {"compare", "reduce", "fp64_probe"}
                    or outputs["numeric_verdict"].item() != 2 or outputs["counts"].any()
                    or not np.isnan(outputs["metrics"]).all()):
                return "ERROR", "VALIDATOR_DIAGNOSTIC_OUTPUT_INVALID"
        elif fp64 and fp64["status"] == "PASS":
            tol = profile["validator_metric_tolerance"]
            if (outputs["numeric_verdict"].item() != numeric.verdict or not np.array_equal(outputs["counts"], numeric.counts)
                    or not np.allclose(outputs["metrics"], numeric.metrics, atol=tol["atol"], rtol=tol["rtol"], equal_nan=True)):
                return "ERROR", "VALIDATOR_DISAGREEMENT"
        if not case["dtype"] and numeric.math_status != "PASS":
            return numeric.math_status, "VALIDATOR_DISAGREEMENT"
        if not skip_device_fp64 and (not fp64 or fp64["status"] != "PASS"):
            return "UNSUPPORTED", fp64["status"] if fp64 else "MISSING_EVIDENCE"
    else:
        needed = _diagnostic_roles(group, item)
    if not needed <= observed:
        return "UNSUPPORTED", "MISSING_EVIDENCE"
    return "PASS", None


def _diagnostic_roles(group, item):
    if group == 2:
        return {"stage_a", "stage_b"}
    if group == 4 and item != 2:
        return set()
    roles = {"stage_c", "stage_d"}
    if group == 6 or group == 5 and item >= 5:
        roles |= {"stage_e", "stage_f"}
    return roles


def fixed_nonce(fields):
    return hashlib.sha256(b"compute_audit.reference.v3.1\0" + bytes.fromhex(fields["context_hex"])).digest()


def g4_copy_enabled(plan, case):
    return "trace_evidence_version" in plan and plan.get("skip_device_fp64") is True and case["case_id"] == "G4"


def _operator_observed(root, profile, plan, case, row):
    activities = row["operator_activities"]
    copies = [activity for activity in activities if activity["role"] == "operator_copy"]
    if not copies:
        return any(activity["role"] == "operator" for activity in activities)
    if not g4_copy_enabled(plan, case) or len(activities) != 1:
        raise AuditError("OPERATOR_COPY_EVIDENCE_INVALID")
    activity = copies[0]
    proof = activity.get("copy_proof")
    calibration = row["binding"].get("kineto_calibration")
    identity = {"raw_device": activity["raw_device"], "raw_stream": activity["stream"],
                "start_us": activity["start_us"], "duration_us": activity["duration_us"]}
    if (not isinstance(proof, dict) or not calibration or activity["raw_device"] != calibration["raw_device"]
            or activity["stream"] != calibration["raw_stream"] or any(proof.get(k) != v for k, v in identity.items())):
        raise AuditError("OPERATOR_COPY_EVIDENCE_INVALID")
    limit = profile["max_host_working_bytes"]
    inputs, result = row["inputs"], row["actual"]
    if inputs.keys() != G4_SHAPES.keys():
        raise AuditError("OPERATOR_COPY_EVIDENCE_INVALID")
    layouts = [(inputs[name], shape) for name, shape in G4_SHAPES.items()]
    layouts.append((result, G4_SHAPES["c"]))
    if any(meta["dtype"] != case["dtype"] or meta["shape"] != list(shape) or meta["strides"] != [shape[1], 1]
           for meta, shape in layouts):
        raise AuditError("OPERATOR_COPY_EVIDENCE_INVALID")
    c_bits, result_bits = (read_tensor(root, meta, limit, bits=True) for meta in (inputs["c"], result))
    if (not validate_g4_copy(proof, case, (c_bits, row["operator_args"]), result_bits)
            or proof["cpu"]["pid"] != row["binding"]["process_id"]):
        raise AuditError("OPERATOR_COPY_EVIDENCE_INVALID")
    return True


def evaluate(root, profile, plan, case, row):
    numeric, operator_status = None, None
    exception = row["exception"]
    if case["dtype"] or (row["invocation_type"] == "core" and not exception):
        numeric = _evaluate_math(root, profile, plan, case, row)
        if case["dtype"]:
            operator_status = numeric.math_status
            observed = _operator_observed(root, profile, plan, case, row)
            if operator_status == "PASS" and not observed:
                operator_status = "UNSUPPORTED"
    if exception:
        errors = {"VALIDATOR_FAILED": "FAIL", "VALIDATOR_ERROR": "ERROR", "VALIDATOR_UNAVAILABLE": "ERROR"}
        if exception not in errors or row["outputs"] or row["activities"]:
            raise AuditError("INVALID_VALIDATOR_FAILURE_RECORD")
        validator_status, reason = errors[exception], "VALIDATOR_FAILED"
    else:
        validator_status, reason = _output_checks(root, profile, plan, case, row, numeric)
    if not reason and operator_status not in (None, "PASS"):
        reason = "MISSING_EVIDENCE" if operator_status == "UNSUPPORTED" else "COMPUTE_DISAGREEMENT"
    checks = dict(validator_status=validator_status, operator_status=operator_status, reason=reason)
    return next((value for value in ("FAIL", "ERROR", "UNSUPPORTED") if value in (operator_status, validator_status)), "PASS"), checks




BINDING_FIELDS = ("pci_bus_id", "runtime_index", "process_id", "fp64_capability")


def _check_activities(activities, binding, roles, *, calibrated):
    calibration = binding.get("kineto_calibration")
    fields = {"device", "raw_device", "stream", "role", "source", "start_us", "duration_us"}
    for activity in activities:
        if (activity["device"] != binding["runtime_index"] or activity["source"] != "kineto"
                or type(activity["stream"]) is not int or activity["duration_us"] < 0):
            raise AuditError("DEVICE_ACTIVITY_INVALID")
        if not calibrated:
            continue
        role = activity["role"]
        expected = fields | {"copy_proof"} if role == "operator_copy" else fields
        if (calibration is None or activity.keys() != expected or type(activity["device"]) is not int
                or type(activity["raw_device"]) is not int or activity["raw_device"] != calibration["raw_device"]
                or activity["stream"] < 0 or role not in roles
                or any(type(activity[key]) not in (int, float) or not 0 <= activity[key] <= 1e20
                       for key in ("start_us", "duration_us"))):
            raise AuditError("DEVICE_ACTIVITY_INVALID")


def verify_events(root, manifest, plan, binding_fields, *, optional_binding=()):
    previous = "0" * 64
    events = []
    terminals, active_devices, active_cases, bindings = {}, set(), set(), {}
    planned = {row["record_id"]: row["target_id"] for row in plan["cases"]}
    within = {"compute_end", "validate_kernel_end", "host_recheck_end", "validation_end", "timing_sample"}
    lifecycle = {"run_start", "run_end", "device_start", "device_end", "device_bind", "case_start", "case_end", "worker_end"}
    phase = {}
    last = -1
    for number, event in enumerate(read_jsonl(root / "events.jsonl"), 1):
        signature = event.pop("event_hash")
        name, target, case = event["event_type"], event.get("target_id"), event.get("record_id")
        if (signature != event_hash(event, previous) or event["seq"] != number or event["run_id"] != plan["run_id"]
                or event["plan_sha256"] != manifest["plan_sha256"] or event["monotonic_ns"] < last or name not in (within | lifecycle)):
            raise AuditError("EVENT_CHAIN_INVALID")
        if name == "device_start":
            if active_devices:
                raise AuditError("OVERLAPPING_DEVICE_ACTIVITY")
            active_devices.add(target)
        elif name == "device_end":
            if target not in active_devices:
                raise AuditError("DEVICE_EVENT_ORDER_INVALID")
            active_devices.remove(target)
            active_cases.difference_update([item for item in active_cases if planned[item] == target])
        elif name == "case_start":
            if target not in active_devices or planned.get(case) != target or case in active_cases or case in terminals:
                raise AuditError("CASE_EVENT_ORDER_INVALID")
            active_cases.add(case)
        elif name == "device_bind":
            if target not in active_devices or target in bindings:
                raise AuditError("DEVICE_BIND_EVENT_INVALID")
            fields = (*binding_fields, *(key for key in optional_binding if key in event))
            bindings[target] = {key: event[key] for key in fields}
        elif name == "case_end":
            if case not in active_cases or planned.get(case) != target:
                raise AuditError("CASE_EVENT_ORDER_INVALID")
            active_cases.remove(case)
            terminals[case] = event["status"]
        elif name in within:
            if case not in active_cases or planned.get(case) != target:
                raise AuditError("INVOCATION_EVENT_ORDER_INVALID")
            key = event["invocation_id"]
            visit = phase.setdefault(key, [])
            order = ("compute_end", "validate_kernel_end", "host_recheck_end", "validation_end", "timing_sample")
            if visit and order.index(name) <= order.index(visit[-1]["event_type"]):
                raise AuditError("INVOCATION_EVENT_ORDER_INVALID")
            visit.append(event)
        previous, last = signature, event["monotonic_ns"]
        events.append(event)
    if (not events or events[0]["event_type"] != "run_start" or events[-1]["event_type"] != "run_end"
            or events[-1]["complete"] != manifest["complete"] or manifest["events"] != len(events) or previous != manifest["event_chain_head"]):
        raise AuditError("EVENTS_UNSEALED")
    return events[-1], terminals, phase, bindings


def _binding_check(row, case, target, plan, phase, binding):
    identity = {"target_id": case["target_id"], "record_id": case["record_id"], "case_id": case["case_id"],
                "attempt_id": "1", "invocation_id": f"{case['record_id']}.1.{row['sample_id']}"}
    if any(row[key] != value for key, value in identity.items()):
        raise AuditError("INVOCATION_BINDING_INVALID")
    if row["exception"] == "VALIDATOR_UNAVAILABLE":
        if row["native_sha256"] is not None or row["validator_abi"] is not None:
            raise AuditError("INVOCATION_BINDING_INVALID")
    elif row["validator_abi"] != plan["validator_abi"] or not row["native_sha256"] or (
            plan["native_sha256"] is not None and row["native_sha256"] != plan["native_sha256"]):
        raise AuditError("INVOCATION_BINDING_INVALID")
    if (row["binding"] != binding or binding["pci_bus_id"] != target["pci_bus_id"]
            or binding["process_id"] != row["process_id"]):
        raise AuditError("INVOCATION_DEVICE_INVALID")
    device = f"cuda:{binding['runtime_index']}"
    if row["device"] != device or any(value["device"] != device for value in row["outputs"].values()):
        raise AuditError("INVOCATION_TENSOR_DEVICE_INVALID")
    calibrated = "trace_evidence_version" in plan
    _check_activities(row["activities"], binding, NATIVE_ROLES.values(), calibrated=calibrated)
    operator_roles = {"operator", "operator_copy"} if g4_copy_enabled(plan, case) else {"operator"}
    _check_activities(row["operator_activities"], binding, operator_roles if case["dtype"] else set(), calibrated=calibrated)
    for event in phase:
        if event["device"] != device or event["process_id"] != row["process_id"] or event["native_sha256"] != row["native_sha256"]:
            raise AuditError("INVOCATION_EVENT_BINDING_INVALID")
    events = {event["event_type"]: event for event in phase}
    if events.get("validation_end", {}).get("status") != row["status"] or events.get("host_recheck_end", {}).get("checks") != row["checks"]:
        raise AuditError("INVOCATION_PHASE_MISSING")
    if ("validate_kernel_end" in events) != (not row["exception"]):
        raise AuditError("INVOCATION_PHASE_MISSING")
    if not row["exception"] and events["validate_kernel_end"]["activities"] != row["activities"]:
        raise AuditError("DEVICE_ACTIVITY_MISMATCH")
    if events.get("compute_end", {}).get("activities", []) != row["operator_activities"]:
        raise AuditError("OPERATOR_ACTIVITY_MISMATCH")
    if row["sample_id"].startswith("sample-") and events.get("timing_sample", {}).get("timing") != row["timing"]:
        raise AuditError("TIMING_EVENT_MISMATCH")


def verify(args, *, replay=False, witness_check=None, custody_check=None):
    """Verify the sealed evidence, optionally using an independent maintenance reference."""
    from .inventory import read_targets
    from .runner import SPLIT_RESULTS, TRACE_EVIDENCE_VERSION, VALIDATOR_ABI, changed_topology, check_parameters, construct_plan, report_rows
    from .worker import _case_status

    root, out = Path(args.bundle).resolve(), Path(args.output).resolve()
    if out.is_relative_to(root):
        raise AuditError("VERIFICATION_OUTPUT_MUST_BE_EXTERNAL")
    manifest, paths = check_manifest(root)
    required = {"plan.json", "profile.json", "inventory.json", "run_context.json", "environment.json",
                "topology_before.json", "topology_after.json", "events.jsonl", "cases.jsonl", "samples.csv",
                "report.json", "report.md", "device-results.csv", "parameters/parameters.json"}
    if not required <= paths or manifest["plan_sha256"] != file_digest(root / "plan.json"):
        raise AuditError("MISSING_BUNDLE_EVIDENCE")
    plan = load(root / "plan.json") | {"plan_sha256": manifest["plan_sha256"]}
    if plan["result_semantics"] != SPLIT_RESULTS or plan["validator_abi"] != VALIDATOR_ABI:
        raise AuditError("RESULT_SEMANTICS_UNSUPPORTED")
    trace_version = plan.get("trace_evidence_version")
    if "trace_evidence_version" in plan and (type(trace_version) is not int or trace_version != TRACE_EVIDENCE_VERSION):
        raise AuditError("TRACE_EVIDENCE_VERSION_UNSUPPORTED")
    binding_fields = (*BINDING_FIELDS, "kineto_calibration") if trace_version is not None else BINDING_FIELDS
    end, terminals, phases, bindings = verify_events(root, manifest, plan, binding_fields)
    if args.integrity_only:
        write(out, {"report_kind": "verify", "verification_status": "PASS", "verification_scope": "integrity_only",
                    "integrity_status": "PASS", "custody_status": "UNANCHORED", "acceptance_eligible": False})
        return Exit.PASS
    context_keys = ("run_id", "run_nonce", "profile_sha256", "inventory_sha256", "release_sha256")
    if any(load(root / "run_context.json").get(key) != plan[key] for key in context_keys):
        raise AuditError("RUN_CONTEXT_MISMATCH")
    for key in ("run_id", "profile_sha256", "inventory_sha256", "release_sha256"):
        value = getattr(args, f"expect_{key}", None)
        if value is not None and value != plan[key]:
            raise AuditError("PLAN_CONTEXT_MISMATCH")
    context = {key: plan[key] for key in (*context_keys, "native_sha256", "validator_abi", "parameters_sha256",
                                         "inventory_snapshot_sha256", "result_semantics")}
    for name, relative in (("profile_sha256", "profile.json"), ("inventory_snapshot_sha256", "inventory.json"),
                           ("parameters_sha256", "parameters/parameters.json")):
        if context[name] != file_digest(root / relative):
            raise AuditError("PLAN_INPUT_MISMATCH")
    if "source_run_id" in plan:
        context["source_run_id"] = plan["source_run_id"]
    profile = normalize_profile(load(root / "profile.json"))
    if profile.get("native_sha256") != plan["native_sha256"]:
        raise AuditError("PLAN_INPUT_MISMATCH")
    targets = read_targets(load(root / "inventory.json"), field=True)
    params = check_parameters(root / "parameters/parameters.json")
    original = construct_plan(profile, context, targets, params, plan["selftest"], trace_evidence_version=trace_version)
    if original | {"plan_sha256": manifest["plan_sha256"]} != plan:
        raise AuditError("PLAN_RECOMPUTATION_MISMATCH")
    skip_device_fp64 = plan.get("skip_device_fp64", False)
    for binding in bindings.values():
        calibration = binding.get("kineto_calibration")
        if calibration is not None and not validate_binding(calibration, binding, binding["runtime_index"]):
            raise AuditError("KINETO_CALIBRATION_INVALID")
        fp64 = binding["fp64_capability"]
        if skip_device_fp64 and fp64 is not None:
            raise AuditError("UNEXPECTED_FP64_PROBE")
        if fp64 is not None and trace_version is not None:
            _check_activities(fp64["activities"], binding, {"fp64_probe"}, calibrated=True)
        if fp64 and check_fp64_probe(root, fp64, profile["max_host_working_bytes"]) != fp64["status"]:
            raise AuditError("FP64_PROBE_STATUS_MISMATCH")
    by_id = {row["target_id"]: row for row in targets}
    cases = list(read_jsonl(root / "cases.jsonl"))
    if len(cases) != len(plan["cases"]):
        raise AuditError("CASE_COVERAGE_MISMATCH")
    seen, samples, witnessed = set(), [], 0
    for expected, case in zip(plan["cases"], cases, strict=True):
        if any(case.get(key) != value for key, value in expected.items() if key != "invocations") or case["status"] not in CASE_STATES:
            raise AuditError("CASE_COVERAGE_MISMATCH")
        selected = case["invocations"]
        if not selected:
            if "PASS" in (case["status"], case.get("operator_status"), case.get("validator_status")) or not case.get("reason"):
                raise AuditError("CASE_EVIDENCE_MISSING")
            continue
        interrupted = case.get("interrupted", False)
        if ((interrupted and case.get("interruption_reason") != "DEVICE_CONTEXT_LOST")
                or len(selected) > len(expected["invocations"])
                or not interrupted and len(selected) != len(expected["invocations"])
                or terminals.get(case["record_id"]) != case["status"]):
            raise AuditError("INVOCATION_COVERAGE_MISMATCH")
        target = by_id[case["target_id"]]
        for call, info in zip(expected["invocations"], selected):
            if info["path"] not in paths:
                raise AuditError("INVOCATION_FILE_MISSING")
            row = load(safe_path(root, info["path"]))
            iid = row["invocation_id"]
            if (iid in seen or iid not in phases or row["sample_id"] != info["sample_id"]
                    or any(row[key] != value for key, value in call.items())):
                raise AuditError("INVOCATION_COVERAGE_MISMATCH")
            seen.add(iid)
            _binding_check(row, case, target, plan, phases[iid], bindings[target["target_id"]])
            status, checks = evaluate(root, profile, plan, case, row)
            if (row["checks"] != checks or any(row.get(key) != value or info.get(key) != value
                    for key, value in {"status": status, "operator_status": checks["operator_status"],
                                       "validator_status": checks["validator_status"]}.items())):
                raise AuditError("RECOMPUTED_RESULT_MISMATCH")
            if witness_check and not row["exception"] and row["validator_status"] in ("PASS", "UNSUPPORTED"):
                witness_check(target, row, root, profile["max_host_working_bytes"])
                witnessed += 1
            if row["sample_id"].startswith("sample-"):
                samples.append({"record_id": case["record_id"], "sample_id": row["sample_id"], "status": status, **row["timing"]})
        if row["interrupted"] is not interrupted or any(case.get(key) != _case_status(selected, key)
                for key in ("status", "operator_status", "validator_status")):
            raise AuditError("CASE_STATUS_MISMATCH")
    if seen != phases.keys():
        raise AuditError("UNACCOUNTED_INVOCATION")
    with (root / "samples.csv").open(newline="", encoding="utf-8") as stream:
        sample_csv = list(csv.DictReader(stream))
    if len(sample_csv) != len(samples) or any(any(str(value) != row.get(key) for key, value in sample.items() if value is not None)
                                              for sample, row in zip(samples, sample_csv)):
        raise AuditError("TIMING_DATA_MISMATCH")
    report = load(root / "report.json")
    before, after = (load(root / f"topology_{position}.json") for position in ("before", "after"))
    full_scope = profile["scope"] == "acceptance"
    scope_mismatch = full_scope and {item["pci_bus_id"] for item in before["physical"]} != {item["pci_bus_id"] for item in targets}
    recomputed = aggregate(cases, incomplete=not manifest["complete"] or scope_mismatch or changed_topology(before, after, targets),
                           allow_unsupported=not full_scope)
    if (recomputed.name != end["status"] or recomputed.name != report["declared_run_status"]
            or report_rows(targets, cases) != report["devices"]
            or report.get("skip_device_fp64", False) is not skip_device_fp64):
        raise AuditError("RECOMPUTED_REPORT_MISMATCH")
    custody = custody_check(args, root, plan, report) if custody_check else False
    qualifies = (args.require_acceptance and not skip_device_fp64 and custody and witnessed > 0 and recomputed == Exit.PASS
                 and full_scope and profile["profile_status"] == "released" and not plan["selftest"])
    final = Exit.INCOMPLETE if args.require_acceptance and recomputed == Exit.PASS and not qualifies else recomputed
    timing = [item["device_event_ms"] for item in samples if type(item.get("device_event_ms")) in (int, float) and item["device_event_ms"] >= 0]
    write(out, dict(report_kind="reference_replay" if replay else "verify", verification_status="PASS",
                    verification_scope="diagnostic_no_device_fp64" if skip_device_fp64 else "full_numeric",
                    integrity_status="PASS", custody_status="ANCHORED" if custody else "UNANCHORED", final_status=final.name,
                    recomputed_run_status=recomputed.name, acceptance_eligible=qualifies, source_run_id=plan["run_id"],
                    witnessed_invocations=witnessed,
                    timing={"sample_count": len(timing), "p50_p95_ms": np.quantile(timing, [.5, .95], method="linear").tolist() if timing else None}))
    return final
