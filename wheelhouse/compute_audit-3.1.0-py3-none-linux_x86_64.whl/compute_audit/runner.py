"""Freeze a run and supervise independent, serial GPU workers."""

import multiprocessing
import os
import queue
import shutil
import sys
import time
from pathlib import Path
from uuid import uuid4

from .artifacts import Events, csv_rows, jsonl, read_jsonl, seal
from .challenge import PARAMETERS_A, PARAMETERS_B
from .config import build_cases, catalog_digest
from .contracts import AuditError, Exit, aggregate, file_digest, identifier, load, write
from .inventory import match_target, pci_id, read_targets, select, snapshot
from .probe import probe
from .public_results import OPERATORS, card_label, operator_label, status_label


SPLIT_RESULTS = "operator_split_v2"
VALIDATOR_ABI = "3.1"
TRACE_EVIDENCE_VERSION = 1


def _defaults(args):
    release = os.environ.get("COMPUTE_AUDIT_RELEASE_DIR")
    materials = Path(release or ".")
    return Path(args.parameters or materials / "parameters/parameters.json")


def check_parameters(path):
    params = load(path)
    if (params.get("modulus") != 65521 or params.get("sets") != {"A": list(PARAMETERS_A), "B": list(PARAMETERS_B)}
            or params.get("parameters") != list(PARAMETERS_A) or params.get("test_only") is not True):
        raise AuditError("PARAMETER_SET_MISMATCH")
    return params["parameters"]


def _expected(args, field, path):
    actual = file_digest(path)
    expected = getattr(args, f"expect_{field}_sha256", None)
    if expected is not None and expected != actual:
        raise AuditError(f"{field.upper()}_DIGEST_MISMATCH")
    return actual


def _release(args, profile_path=None):
    from .release_verify import verify_installation

    options = [os.environ.get(f"COMPUTE_AUDIT_{key}") for key in ("RELEASE_DIR", "TRUST_KEY", "INSTALL_RECORD")]
    expected = getattr(args, "expect_release_sha256", None)
    if any(value is None for value in options) or not expected:
        raise AuditError("INDEPENDENT_RELEASE_INPUT_MISSING")
    root, trust, record = options
    result = verify_installation(root, trust, expected, record)
    if profile_path is not None and not Path(profile_path).resolve().is_relative_to(Path(root).resolve() / "profiles"):
        raise AuditError("PROFILE_NOT_IN_RELEASE")
    if Path(sys.prefix).resolve() != Path(result["prefix"]).resolve() or os.getenv("COMPUTE_AUDIT_NATIVE_LIBRARY"):
        raise AuditError("PROCESS_ENVIRONMENT_NOT_RELEASED")
    return result


def construct_plan(profile, context, targets, parameters, selftest, *, trace_evidence_version=TRACE_EVIDENCE_VERSION):
    precision = {"skip_device_fp64": True} if profile.get("skip_device_fp64") else {}
    trace = {} if trace_evidence_version is None else {"trace_evidence_version": trace_evidence_version}
    return context | precision | trace | {"schema_version": "3.0", "selftest": selftest, "catalog_sha256": catalog_digest(),
                      "execution_mode": profile["execution_mode"], "execution_variant": profile["execution_variant"],
                      "challenge_length": profile["challenge_length"], "parameters": parameters,
                      "targets": targets, "cases": build_cases(targets, profile, selftest=selftest)}


def _supervise(root, target, plan, cases, profile, events, replay):
    from .worker import worker_main

    ctx = multiprocessing.get_context("spawn")
    channel = ctx.Queue()
    process = ctx.Process(target=worker_main, args=(channel, str(root), target, plan, cases, profile, replay))
    process.start()
    started = time.monotonic()
    case_started, current = started, None
    results, failure = {}, None
    try:
        while True:
            now = time.monotonic()
            if now - started >= profile["max_device_seconds"] or current and now - case_started >= profile["max_case_seconds"]:
                failure = {"status": "ERROR", "reason": "DEVICE_OR_CASE_TIMEOUT"}
                break
            try:
                event, data = channel.get(timeout=0.2)
            except queue.Empty:
                if not process.is_alive():
                    failure = {"status": "ERROR", "reason": "WORKER_EXIT_WITHOUT_TERMINAL"}
                    break
                continue
            if event == "done":
                break
            if event == "worker_error":
                failure = data
            elif event == "device_bind":
                events.emit(event, target_id=target["target_id"], **data)
            elif event == "case_start":
                current, case_started = data, time.monotonic()
                events.emit(event, target_id=target["target_id"], record_id=data, process_id=process.pid)
                print(f"{target['target_id']}  {data}  {len(results) + 1}/{len(cases)}", file=sys.stderr)
            elif event == "case_end":
                results[data["record_id"]] = data
                for invocation in data["invocations"]:
                    row = load(root / invocation["path"])
                    base = {key: row[key] for key in ("target_id", "record_id", "case_id", "attempt_id", "sample_id", "invocation_id", "process_id", "device", "native_sha256")}
                    if row["operator_activities"]:
                        events.emit("compute_end", **base, activities=row["operator_activities"])
                    if not row["exception"]:
                        events.emit("validate_kernel_end", **base, activities=row["activities"])
                    events.emit("host_recheck_end", **base, checks=row["checks"])
                    events.emit("validation_end", **base, status=row["status"])
                    if row["sample_id"].startswith("sample-"):
                        events.emit("timing_sample", **base, timing=row["timing"])
                events.emit(event, target_id=target["target_id"], record_id=data["record_id"], status=data["status"], process_id=process.pid)
                current = None
    finally:
        process.join(timeout=1)
        if process.is_alive():
            process.terminate()
            process.join(timeout=2)
        if process.is_alive():
            process.kill()
            process.join()
        events.emit("worker_end", target_id=target["target_id"], process_id=process.pid, exitcode=process.exitcode)
        channel.close()
    if process.exitcode and not failure:
        failure = {"status": "ERROR", "reason": f"WORKER_EXIT_{process.exitcode}"}
    return results, failure


def report_rows(targets, records):
    result = []
    for target in targets:
        rows = [row for row in records if row["target_id"] == target["target_id"]]
        operators = {}
        for name in ("GEMM", "RMSNorm", "SDPA", "Validate Compute"):
            if name == "Validate Compute":
                relevant = [row | {"status": "SKIPPED" if row.get("validator_status") == "NOT_RUN" else row.get("validator_status", row["status"])} for row in rows
                            if row["operator"] == name or row.get("validator_status") is not None]
            else:
                relevant = [row | {"status": row.get("operator_status", row["status"])} for row in rows if row["operator"] == name]
            operators[name] = aggregate(relevant).name if relevant else "NOT_RUN"
        result.append(dict(target_id=target["target_id"], pci_bus_id=target.get("pci_bus_id"), **operators,
                           required_total=sum(row["required"] for row in rows),
                           required_completed=sum(row["required"] and bool(row["invocations"]) and not row.get("interrupted") for row in rows),
                           required_passed=sum(row["required"] and row["status"] == "PASS" for row in rows),
                           status=aggregate(rows).name, reasons=sorted({row["reason"] for row in rows if row.get("reason")})))
    return result


def changed_topology(before, after, targets, keys=("pci_bus_id", "runtime_index")):
    def fingerprint(state):
        buses = {target.get("pci_bus_id") for target in targets}
        return [[tuple(row.get(key) for key in keys) for row in state[kind] if row.get("pci_bus_id") in buses]
                for kind in ("physical", "visible")]
    return fingerprint(before) != fingerprint(after)


def run(args, profile, *, selftest=False):
    output = Path(args.output).resolve()
    formal = profile["scope"] == "acceptance"
    replay = None
    if getattr(args, "replay_source", None):
        origin = Path(args.replay_source)
        archive = {}
        for row in read_jsonl(origin / "cases.jsonl"):
            if row["dtype"] and row["invocations"]:
                identity = f"{row['case_id']}.{row['dtype']}"
                first = load(origin / row["invocations"][0]["path"])
                archive.setdefault(identity, {key: first[key] for key in ("inputs", "operator_args")})
        replay = (origin, archive)
    if formal and (profile["profile_status"] != "released" or profile.get("validator_abi") != VALIDATOR_ABI
                   or profile.get("catalog_sha256") != catalog_digest() or args.devices != "all"
                   or any(not getattr(args, name) for name in ("inventory", "expect_inventory_sha256", "expect_profile_sha256", "run_id", "run_context"))):
        raise AuditError("FORMAL_PROFILE_OR_CONTEXT_INVALID")
    release_result = _release(args, args.profile) if formal else None
    before = snapshot()
    inventory = load(args.inventory) if args.inventory else {"schema_version": "3.0", "scope": args.devices,
                                                              "targets": select(before, args.devices)}
    targets = read_targets(inventory, field=True)
    if not targets:
        if before["visible"] or args.inventory:
            raise AuditError("EMPTY_PLAN")
        output.mkdir(parents=True, exist_ok=False, mode=0o700)
        write(output / "probe.json", probe())
        return Exit.UNSUPPORTED
    if formal and ({row.get("pci_bus_id") for row in targets} != {row["pci_bus_id"] for row in before["physical"]}):
        # The approved denominator is preserved; mark the outcome incomplete independently.
        scope_mismatch = True
    else:
        scope_mismatch = False
    parameters_source = _defaults(args)
    if formal:
        release_root = Path(os.environ["COMPUTE_AUDIT_RELEASE_DIR"]).resolve()
        if parameters_source.resolve() != release_root / "parameters/parameters.json":
            raise AuditError("MATERIALS_NOT_IN_RELEASE")
    parameters = check_parameters(parameters_source)
    parameters_sha = file_digest(parameters_source)
    native_sha = release_result["native_sha256"] if release_result else profile.get("native_sha256")
    for field, obtained in (("native_sha256", native_sha), ("parameters_sha256", parameters_sha)):
        if (formal or profile.get(field) is not None) and profile.get(field) != obtained:
            raise AuditError(f"PROFILE_{field.upper()}_MISMATCH")
    profile_sha = _expected(args, "profile", args.profile)
    inventory_sha = _expected(args, "inventory", args.inventory) if args.inventory else None
    output.mkdir(parents=True, exist_ok=False, mode=0o700)
    shutil.copyfile(args.profile, output / "profile.json")
    write(output / "inventory.json", {"schema_version": "3.0", "targets": targets})
    inventory_snapshot_sha = file_digest(output / "inventory.json")
    if inventory_sha is None:
        inventory_sha = inventory_snapshot_sha
    run_id = identifier(args.run_id or str(uuid4()))
    context = {"run_id": run_id, "profile_sha256": profile_sha, "inventory_sha256": inventory_sha,
               "release_sha256": args.expect_release_sha256 if formal else None}
    run_context = load(args.run_context) if args.run_context else context | {"run_nonce": os.urandom(32).hex()}
    if any(run_context.get(k) != v for k, v in context.items()) or len(bytes.fromhex(run_context["run_nonce"])) != 32:
        raise AuditError("RUN_CONTEXT_MISMATCH")
    if args.run_context:
        shutil.copyfile(args.run_context, output / "run_context.json")
    else:
        write(output / "run_context.json", run_context)
    (output / "parameters").mkdir()
    shutil.copyfile(parameters_source, output / "parameters/parameters.json")
    if release_result:
        write(output / "release-evidence.json", release_result)
        evidence_dir = output / "release-evidence"
        for relative in ("release-manifest.json", "release-manifest.json.sig", "parameters/parameters.json.sig"):
            source = release_root / relative
            if source.is_file():
                destination = evidence_dir / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
    context |= {"run_nonce": run_context["run_nonce"], "native_sha256": native_sha, "validator_abi": VALIDATOR_ABI,
                "parameters_sha256": parameters_sha, "inventory_snapshot_sha256": inventory_snapshot_sha,
                "result_semantics": SPLIT_RESULTS}
    if replay:
        context["source_run_id"] = identifier(args.source_run_id)
    plan = construct_plan(profile, context, targets, parameters, selftest)
    if not plan["cases"] or not any(row["required"] for row in plan["cases"]):
        raise AuditError("EMPTY_REQUIRED_PLAN")
    write(output / "plan.json", plan)
    plan["plan_sha256"] = file_digest(output / "plan.json")
    if getattr(args, "plan_only", False):
        print(f"{plan['plan_sha256']}  {output / 'plan.json'}")
        return Exit.PASS
    if formal:
        registration = getattr(args, "plan_registration", None)
        if not registration or Path(registration).resolve().is_relative_to(output):
            raise AuditError("INDEPENDENT_PLAN_REGISTRATION_REQUIRED")
        registered = load(registration)
        if any(registered.get(key) != plan[key] for key in ("run_id", "plan_sha256", "profile_sha256", "inventory_sha256")):
            raise AuditError("PLAN_REGISTRATION_MISMATCH")
        shutil.copyfile(registration, output / "plan_registration.json")
    write(output / "topology_before.json", before)
    write(output / "environment.json", probe())
    events = Events(output / "events.jsonl", run_id, plan["plan_sha256"])
    events.emit("run_start")
    records, completed = [], set()
    stopped = False
    try:
        for target in plan["targets"]:
            target_id = target["target_id"]
            cases = [case for case in plan["cases"] if case["target_id"] == target_id]
            events.emit("device_start", target_id=target_id)
            _, reason = match_target(target, before)
            if reason:
                results = {}
                failure = {"status": "UNSUPPORTED" if reason == "DEVICE_MAPPING_MISSING" else "ERROR", "reason": reason}
            else:
                ordered = sorted(cases, key=lambda case: case["operator"] == "Validate Compute")
                results, failure = _supervise(output, target, plan, ordered, profile, events, replay)
            for case in cases:
                result = results.get(case["record_id"], (failure or {"status": "ERROR", "reason": "MISSING_CASE_TERMINAL"}) | {"invocations": []})
                records.append(case | result)
                completed.add(case["record_id"])
            events.emit("device_end", target_id=target_id, cases=len(results), failure=failure)
    except KeyboardInterrupt:
        stopped = True
    for case in plan["cases"]:
        if case["record_id"] not in completed:
            records.append(case | {"status": "SKIPPED", "reason": "RUN_INTERRUPTED", "invocations": []})
    after = snapshot()
    write(output / "topology_after.json", after)
    topology_changed = changed_topology(before, after, plan["targets"])
    code = aggregate(records, incomplete=stopped or topology_changed or scope_mismatch, allow_unsupported=not formal)
    rows = report_rows(plan["targets"], records)
    report = {"schema_version": "3.0", "report_kind": "device_replay" if replay else "selftest" if selftest else "run", "scope": profile["scope"],
              "profile_status": profile["profile_status"], "acceptance_eligible": False, "declared_run_status": code.name,
              "devices": rows, "required": {"total": sum(row["required_total"] for row in rows),
                                             "completed": sum(row["required_completed"] for row in rows),
                                             "passed": sum(row["required_passed"] for row in rows)},
              "topology_changed": topology_changed, "scope_mismatch": scope_mismatch, **context, "plan_sha256": plan["plan_sha256"]}
    if plan.get("skip_device_fp64"):
        report["skip_device_fp64"] = True
    jsonl(output / "cases.jsonl", records)
    samples = []
    for case in records:
        for invocation in case["invocations"]:
            if invocation["sample_id"].startswith("sample-"):
                value = load(output / invocation["path"])
                samples.append({"record_id": case["record_id"], "sample_id": invocation["sample_id"], "status": value["status"], **value["timing"]})
    csv_rows(output / "samples.csv", samples, ["record_id", "sample_id", "status", "sync_wall_ms", "device_event_ms", "transfer_e2e_ms",
                                               "validate_device_ms", "validate_sync_wall_ms", "host_recheck_ms", "validation_e2e_ms"])
    csv_rows(output / "device-results.csv", rows, ["target_id", "pci_bus_id", "GEMM", "RMSNorm", "SDPA",
                                                    "Validate Compute", "required_total", "required_completed", "required_passed", "status", "reasons"])
    write(output / "report.json", report)
    fields = ("算力卡", *map(operator_label, OPERATORS), "必测通过", "结论")
    markdown = [f"# 算力卡验证结果\n\n整机结论 **{status_label(code.name)}**\n",
                "| " + " | ".join(fields) + " |", "|---|---|---|---|---|---|---|"]
    if plan.get("skip_device_fp64"):
        markdown.insert(1, "本轮已跳过 GPU FP64 检查，结果仅供诊断。\n")
    for ordinal, row in enumerate(rows, 1):
        results = ["执行失败" if row[op] == "FAIL" else status_label(row[op]) for op in OPERATORS]
        coverage = f"{row['required_passed']}/{row['required_total']}"
        markdown.append("| " + " | ".join((card_label(ordinal), *results, coverage, status_label(row["status"]))) + " |")
    (output / "report.md").write_text("\n".join(markdown) + "\n", encoding="utf-8")
    events.emit("run_end", status=code.name, complete=not stopped)
    events.close()
    seal(output, plan["plan_sha256"], events.seq, events.head, not stopped)
    print(f"{code.name}  {output / 'report.md'}")
    return code
