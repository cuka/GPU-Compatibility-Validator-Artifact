"""Execute the scheduled cases on one physical GPU."""

import os
import time
from pathlib import Path

import numpy as np

from .artifacts import restore_tensor, tensor
from .challenge import PARAMETERS_B
from .config import tolerance
from .contracts import AuditError, write
from .field_verifier import FP64_PROBE_INPUT, check_fp64_probe, dynamic_input, evaluate, fixed_nonce, g4_copy_enabled
from .inventory import match_target, snapshot
from .kineto_binding import calibrate
from .kineto_copy import collect_g4_copy
from .operators import invoke, make_inputs, quantize
from .reference import numeric_vector, reference
from .validate_op import capture, load_native


DIAGNOSTIC_OUTPUTS = ("challenge_output", "status", "witness")
CORE_OUTPUTS = ("metrics", "counts", "numeric_verdict", *DIAGNOSTIC_OUTPUTS)


def _case_status(results, field="status"):
    states = {item[field] for item in results if item.get(field) is not None}
    if not states:
        return None
    return next(status for status in ("FAIL", "ERROR", "RESOURCE_LIMIT", "UNSUPPORTED", "SKIPPED", "PASS") if status in states)


def _cpu_value(value):
    return value.detach().cpu().double().numpy()


def _resource_check(torch, device, tensors, profile, ref_bytes):
    raw = sum(value.numel() * value.element_size() for value in tensors.values())
    estimate = 4 * raw + 16 * ref_bytes + 65536 + 32 * profile["challenge_length"]
    free, _ = torch.cuda.mem_get_info(device)
    if estimate > min(profile["max_device_working_bytes"], free * profile["max_device_free_memory_fraction"], profile["max_host_working_bytes"]):
        raise AuditError("RESOURCE_LIMIT")


def _timed_operation(torch, device, fn, info):
    clock = time.perf_counter_ns
    begin = clock()
    first, last = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    first.record()
    output = fn()
    last.record()
    last.synchronize()
    info.update(sync_wall_ms=(clock() - begin) / 1e6, device_event_ms=first.elapsed_time(last))
    return output


def _capture_options(binding):
    return {"binding": binding} if "kineto_calibration" in binding else {}


def execute_case(root, torch, device, ops, initialization_failed, native_meta, profile, plan, case, process_info, replay):
    case_id, dtype = case["case_id"], case["dtype"]
    skip_device_fp64 = plan.get("skip_device_fp64", False)
    base = f"artifacts/{case['record_id']}"
    trace_options = _capture_options(process_info)
    calibration = process_info.get("kineto_calibration")
    inputs = {}
    operator_args = None
    if dtype:
        values, operator_args = make_inputs(case_id, profile["seed"], profile["rmsnorm_eps"])
        if ((case_id.startswith("R") and not hasattr(torch.nn.functional, "rms_norm"))
                or (case_id.startswith("S") and not hasattr(torch.nn.functional, "scaled_dot_product_attention"))
                or (dtype == "bfloat16" and not torch.cuda.is_bf16_supported())):
            raise AuditError("API_OR_DTYPE_UNSUPPORTED")
        if replay:
            source = replay[1].get(f"{case_id}.{dtype}")
            if source is None:
                raise AuditError("REPLAY_ARCHIVED_INPUT_MISSING")
            operator_args = source["operator_args"]
            samples = {name: restore_tensor(replay[0], value, profile["max_host_working_bytes"])
                       for name, value in source["inputs"].items()}
        else:
            samples = quantize(values, case_id, dtype)
        expected_host = reference(case_id, {name: _cpu_value(value) for name, value in samples.items()}, operator_args,
                                  profile["reference_block_query_rows"])
        _resource_check(torch, device, samples, profile, expected_host.nbytes)
        inputs = {n: tensor(root, f"{base}/inputs/{n}.bin", t) for n, t in samples.items()}
        for _ in range(profile["warmup_iterations"]):
            invoke(case_id, {name: value.to(device) for name, value in samples.items()}, operator_args)
        torch.cuda.synchronize(device)
    else:
        values, expected_host, atol, _ = numeric_vector(case_id) if case_id.startswith("V") else ([1.], [1.], 0., 0)
        expected_host = np.asarray(expected_host, dtype=np.float64)
        samples = {"actual": torch.tensor(values, dtype=torch.float64)}
        inputs = {"actual": tensor(root, f"{base}/inputs/actual.bin", samples["actual"])}
        _resource_check(torch, device, samples, profile, expected_host.nbytes)
    ref_device = None
    ref_attachment = None
    result_rows = []
    context_lost = False
    for entry in case["invocations"]:
        sample_id, kind, mode = (entry[key] for key in ("sample_id", "invocation_type", "input_mode"))
        prefix = f"{base}/{sample_id}"
        timing = {}
        operator_activities = []
        row = dict(entry, target_id=case["target_id"], record_id=case["record_id"], case_id=case_id,
                   attempt_id="1", invocation_id=f"{case['record_id']}.1.{sample_id}", inputs=inputs,
                   operator_args=operator_args, reference=ref_attachment,
                   device=str(device), process_id=os.getpid(), binding=process_info, **native_meta)
        row["base_input"] = {"tensors": inputs, "math": operator_args} if dtype else {"tensors": inputs, "case_id": case_id}

        def u8(field):
            return torch.tensor(list(bytes.fromhex(field)), dtype=torch.uint8, device=device)

        def i64(values):
            return torch.tensor(values, dtype=torch.int64, device=device)

        actual = None
        if dtype:
            start = time.perf_counter_ns()
            data = {name: value.to(device) for name, value in samples.items()}
            actual, operator_activities, _, raw_events = capture(device, lambda: _timed_operation(
                torch, device, lambda: invoke(case_id, data, operator_args), timing), **trace_options)
            actual.cpu()
            timing["transfer_e2e_ms"] = (time.perf_counter_ns() - start) / 1e6
            row["actual"] = tensor(root, f"{prefix}/actual.bin", actual)
            if (calibration is not None and not operator_activities and g4_copy_enabled(plan, case)
                    and inputs["c"]["sha256"] == row["actual"]["sha256"]):
                raw_device, raw_stream = calibration["raw_device"], calibration["raw_stream"]
                proof = collect_g4_copy(raw_events, case, (data, operator_args), actual, raw_device, raw_stream)
                if proof is not None and proof["cpu"]["pid"] == process_info["process_id"]:
                    operator_activities.append({"device": device.index, "raw_device": raw_device, "stream": raw_stream,
                                                "role": "operator_copy", "source": "kineto", "copy_proof": proof,
                                                "start_us": proof["start_us"], "duration_us": proof["duration_us"]})
        validation_started = time.perf_counter_ns()
        if ref_attachment is None:
            if not initialization_failed and not skip_device_fp64:
                ref_device = torch.as_tensor(expected_host, dtype=torch.float64, device=device)
            ref_attachment = tensor(root, f"{base}/reference.bin", expected_host if ref_device is None else ref_device)
        row["reference"] = ref_attachment
        fields, activities, outputs, timings = {}, [], {}, {}
        exception, validation_ms = "VALIDATOR_UNAVAILABLE" if initialization_failed else None, None
        if not initialization_failed:
            item = int(sample_id.split("-")[1]) if case_id.startswith("C") else 0
            parameters = list(PARAMETERS_B) if case_id == "C6" and item == 1 else plan["parameters"]
            fields = dynamic_input(plan, case, row, row["base_input"], parameters)
            fields["nonce_hex"] = (fixed_nonce(fields) if case_id == "C1" and item == 0 else os.urandom(32)).hex()
            challenge = i64(fields["challenge"])
            parameters = i64(fields["parameters"])
            context = u8(fields["context_hex"])
            nonce = u8(fields["nonce_hex"])
            if kind == "core":
                if skip_device_fp64:
                    # Zero elements select the native initialization path. The
                    # same invocation still runs the complete device challenge.
                    if ref_device is None:
                        ref_device = torch.empty(0, dtype=torch.float64, device=device)
                    checked_actual, atol, rtol = ref_device, 0., 0.
                elif dtype:
                    checked_actual = actual.to(torch.float64)
                    atol, rtol = tolerance(profile, case)
                else:
                    checked_actual, rtol = samples["actual"].to(device), 0.
                method, names = ops.validate_compute, CORE_OUTPUTS
                args = (checked_actual, ref_device, challenge, parameters, context, nonce, atol, rtol, profile["relative_floor"])
            else:
                method, names = ops._validate_sample, DIAGNOSTIC_OUTPUTS
                args = (challenge, parameters, context, nonce, int(case_id[1:]), item)
            try:
                result, activities, validation_ms, _ = capture(
                    device, lambda: _timed_operation(torch, device, lambda: method(*args), timings), native=True, **trace_options)
            except (RuntimeError, AttributeError, OSError) as error:
                message = str(error)
                context_lost = any(term in message.lower() for term in (
                    "illegal memory", "illegal address", "device-side assert", "device lost", "device has been lost"))
                exception = "VALIDATOR_FAILED" if message.splitlines()[:1] == ["Execution failed"] else "VALIDATOR_ERROR"
            else:
                outputs = {name: tensor(root, f"{prefix}/{name}.bin", output) for name, output in zip(names, result, strict=True)}
        timing["validate_sync_wall_ms"] = timings.get("sync_wall_ms", validation_ms)
        timing["validate_device_ms"] = timings.get("device_event_ms")
        row.update(outputs=outputs, validation_input=fields, activities=activities, operator_activities=operator_activities,
                   exception=exception, timing=timing, interrupted=context_lost)
        started = time.perf_counter_ns()
        status, checks = evaluate(root, profile, plan, case, row)
        timing["host_recheck_ms"] = (time.perf_counter_ns() - started) / 1e6
        timing["validation_e2e_ms"] = (time.perf_counter_ns() - validation_started) / 1e6
        row.update(status=status, checks=checks, operator_status=checks.get("operator_status"),
                   validator_status=checks["validator_status"])
        name = f"{prefix}/invocation.json"
        write(root / name, row)
        result_rows.append({"path": name, "status": status, "sample_id": sample_id, "reason": checks.get("reason"),
                            "operator_status": row["operator_status"], "validator_status": row["validator_status"]})
        if context_lost:
            break
    status = _case_status(result_rows)
    interruption = {"interrupted": True, "interruption_reason": "DEVICE_CONTEXT_LOST"} if context_lost else {}
    return {**interruption, "status": status, "invocations": result_rows, "operator_status": _case_status(result_rows, "operator_status"),
            "validator_status": _case_status(result_rows, "validator_status"),
            "reason": next((row["reason"] for row in result_rows if row["status"] == status and row["reason"]), None)}


def worker_main(channel, output, target, plan, cases, profile, replay):
    import torch

    root = Path(output)
    try:
        state = snapshot()
        found, reason = match_target(target, state)
        if reason:
            channel.put(("worker_error", {"reason": reason, "status": "UNSUPPORTED" if reason == "DEVICE_MAPPING_MISSING" else "ERROR"}))
            return
        device = torch.device("cuda", found["runtime_index"])
        torch.cuda.set_device(device)
        binding = {"pci_bus_id": found["pci_bus_id"], "runtime_index": found["runtime_index"],
                   "process_id": os.getpid(), "fp64_capability": None}
        if "trace_evidence_version" in plan:
            binding["kineto_calibration"] = calibrate(device, torch, binding)
        ops = None
        meta = dict(native_sha256=None, native_path=None, validator_abi=None)
        try:
            ops, meta = load_native(plan["native_sha256"])
        except (OSError, RuntimeError, ValueError, AttributeError):
            pass
        if ops is not None and not plan.get("skip_device_fp64"):
            try:
                fp64_values = torch.from_numpy(np.array(FP64_PROBE_INPUT, dtype=np.float64)).to(device)
                result, activities, _, _ = capture(device, lambda: ops._fp64_probe(fp64_values), native=True,
                                                   **_capture_options(binding))
            except (RuntimeError, ValueError, AttributeError):
                binding["fp64_capability"] = {"status": "FP64_PROBE_FAILED", "activities": []}
            else:
                prefix = f"artifacts/{target['target_id']}.fp64-probe"
                fp64 = {"input": tensor(root, f"{prefix}/input.bin", fp64_values),
                        "output": tensor(root, f"{prefix}/output.bin", result), "activities": activities}
                fp64["status"] = check_fp64_probe(root, fp64, profile["max_host_working_bytes"])
                binding["fp64_capability"] = fp64
        channel.put(("device_bind", binding))
        with torch.inference_mode():
            for case in cases:
                channel.put(("case_start", case["record_id"]))
                try:
                    outcome = execute_case(root, torch, device, ops, ops is None, meta, profile, plan, case, binding, replay)
                except (RuntimeError, ValueError, TypeError, NotImplementedError) as error:
                    diagnostic = str(error)
                    if diagnostic == "RESOURCE_LIMIT" or isinstance(error, torch.OutOfMemoryError):
                        status = "RESOURCE_LIMIT"
                    elif diagnostic == "API_OR_DTYPE_UNSUPPORTED" or isinstance(error, NotImplementedError) or "unexpected keyword argument 'enable_gqa'" in diagnostic:
                        status = "UNSUPPORTED"
                    else:
                        status = "ERROR"
                    lost = any(term in diagnostic.lower() for term in ("illegal memory", "device-side", "device lost"))
                    outcome = {"status": status, "reason": "DEVICE_CONTEXT_LOST" if lost else status, "invocations": [],
                               "operator_status": status if case["dtype"] else None, "validator_status": "NOT_RUN" if case["dtype"] else status}
                channel.put(("case_end", {"record_id": case["record_id"], **outcome}))
                if outcome.get("interrupted"):
                    channel.put(("worker_error", {"reason": "DEVICE_CONTEXT_LOST", "status": "ERROR"}))
                    break
                if outcome.get("reason") == "DEVICE_CONTEXT_LOST":
                    break
    except Exception:
        channel.put(("worker_error", {"reason": "WORKER_EXECUTION_FAILED", "status": "ERROR"}))
    finally:
        channel.put(("done", None))
