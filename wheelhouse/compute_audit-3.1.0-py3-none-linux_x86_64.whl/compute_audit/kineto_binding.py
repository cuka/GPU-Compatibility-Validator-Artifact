"""Bind Kineto's accelerator numbering to the selected runtime device."""

import math
import os
import re
import secrets

from .inventory import PCI, _runtime_pci


_MARKER_CPU = "aten::bitwise_not"
_MARKER_KERNEL = re.compile(r"\bbitwise_not(?:_kernel)?(?:_cuda)?\b")
_LAUNCH_NAMES = {"hipLaunchKernel", "cudaLaunchKernel"}
_PROOF_FIELDS = {"kind", "device", "pci_bus_id", "process_id", "raw_device", "raw_stream",
                 "marker_input", "marker_output", "cpu", "launch", "kernel"}
_SPAN_FIELDS = {"name", "external_id", "start_us", "duration_us"}


def _ordinal(device):
    if type(device) is int:
        return device
    if getattr(device, "type", None) == "cuda":
        return getattr(device, "index", None)
    return None


def _integer(value, minimum):
    return type(value) is int and value >= minimum


def _physical_matches(binding, ordinal):
    if not isinstance(binding, dict) or not _integer(ordinal, 0):
        return False
    bus = binding.get("pci_bus_id")
    return (_integer(binding.get("runtime_index"), 0) and binding["runtime_index"] == ordinal
            and _integer(binding.get("process_id"), 1) and isinstance(bus, str)
            and len(bus) == 12 and bus == bus.lower() and PCI.fullmatch(bus) is not None)


def _marker_matches(inputs, outputs):
    return (isinstance(inputs, list) and isinstance(outputs, list) and len(inputs) == len(outputs) == 3
            and all(_integer(x, 0) and x < 2**30 for x in inputs)
            and all(type(y) is int for y in outputs) and outputs == [~x for x in inputs])


def _timing(span):
    for key in ("start_us", "duration_us"):
        value = span.get(key)
        if type(value) not in (int, float) or not (0 <= value <= 1e20) or not math.isfinite(value):
            return False
    return True


def validate_binding(proof, physical_binding, logical_device):
    """Independently check an archived marker without importing torch or accessing a GPU."""
    ordinal = _ordinal(logical_device)
    if (not _physical_matches(physical_binding, ordinal)
            or not isinstance(proof, dict) or proof.keys() != _PROOF_FIELDS):
        return False
    if (proof.get("kind") != "bitwise_not_v1" or not _integer(proof.get("device"), 0)
            or proof["device"] != ordinal or proof.get("pci_bus_id") != physical_binding["pci_bus_id"]
            or not _integer(proof.get("process_id"), 1) or proof["process_id"] != physical_binding["process_id"]
            or not _integer(proof.get("raw_device"), 0) or not _integer(proof.get("raw_stream"), 0)
            or not _marker_matches(proof.get("marker_input"), proof.get("marker_output"))):
        return False

    cpu, launch, kernel = (proof.get(key) for key in ("cpu", "launch", "kernel"))
    for span in (cpu, launch, kernel):
        if not isinstance(span, dict) or not _timing(span) or not _integer(span.get("external_id"), 1):
            return False
    if (cpu.keys() != _SPAN_FIELDS | {"pid", "tid"}
            or launch.keys() != _SPAN_FIELDS | {"pid", "tid", "correlation"}
            or kernel.keys() != _SPAN_FIELDS | {"device", "stream", "correlation"}):
        return False
    for span in (cpu, launch):
        if (not _integer(span["pid"], 1) or span["pid"] != proof["process_id"]
                or not _integer(span["tid"], 1) or span["tid"] != cpu["tid"]):
            return False
    if (cpu.get("name") != _MARKER_CPU or launch.get("name") not in ("hipLaunchKernel", "cudaLaunchKernel")
            or kernel.get("name") != "bitwise_not" or not _integer(kernel.get("device"), 0)
            or kernel["device"] != proof["raw_device"] or not _integer(kernel.get("stream"), 0)
            or kernel["stream"] != proof["raw_stream"] or not _integer(launch.get("correlation"), 1)
            or not _integer(kernel.get("correlation"), 1) or launch["correlation"] != kernel["correlation"]
            or not (cpu["external_id"] == launch["external_id"] == kernel["external_id"])):
        return False
    # The GPU executes asynchronously. Only the host launch belongs inside the CPU call.
    return (cpu["start_us"] <= launch["start_us"]
            and launch["start_us"] + launch["duration_us"] <= cpu["start_us"] + cpu["duration_us"]
            and launch["start_us"] <= kernel["start_us"])


def proof_from_events(events, logical_device, physical_binding, marker_input, marker_output):
    """Extract the single marker dispatch from an isolated trace, omitting raw profiler details."""
    ordinal = _ordinal(logical_device)
    if not isinstance(events, list) or not _physical_matches(physical_binding, ordinal):
        return None
    spans = {}
    for event in events:
        if not isinstance(event, dict):
            return None
        if event.get("ph") != "X":
            continue
        category, name = event.get("cat"), event.get("name")
        if not isinstance(name, str):
            if category in ("kernel", "gpu_memcpy", "gpu_memset"):
                return None
            continue
        if category == "cpu_op" and name == _MARKER_CPU:
            role = "cpu"
        elif category in ("cuda_runtime", "hip_runtime", "cuda_driver", "hip_driver") and "launch" in name.lower():
            if name not in _LAUNCH_NAMES:
                return None
            role = "launch"
        elif category == "kernel":
            if not _MARKER_KERNEL.search(name):
                return None
            role, name = "kernel", "bitwise_not"
        elif category in ("gpu_memcpy", "gpu_memset"):
            return None
        else:
            continue
        args = event.get("args")
        if not isinstance(args, dict) or role in spans:
            return None
        span = {"name": name, "external_id": args.get("External id"),
                "start_us": event.get("ts"), "duration_us": event.get("dur")}
        if role in ("cpu", "launch"):
            span.update(pid=event.get("pid"), tid=event.get("tid"))
        if role in ("launch", "kernel"):
            span["correlation"] = args.get("correlation")
        if role == "kernel":
            span.update(device=args.get("device"), stream=args.get("stream"))
        spans[role] = span
    if spans.keys() != {"cpu", "launch", "kernel"}:
        return None
    proof = {"kind": "bitwise_not_v1", "device": ordinal, "pci_bus_id": physical_binding["pci_bus_id"],
             "process_id": physical_binding["process_id"], "raw_device": spans["kernel"]["device"],
             "raw_stream": spans["kernel"]["stream"], "marker_input": marker_input, "marker_output": marker_output,
             **spans}
    return proof if validate_binding(proof, physical_binding, ordinal) else None


def calibrate(device, framework, physical_binding):
    """Calibrate on the worker's current visibility and stream, outside measured invocations."""
    from .validate_op import capture_trace

    ordinal = _ordinal(device)
    if not _physical_matches(physical_binding, ordinal) or physical_binding["process_id"] != os.getpid():
        return None
    try:
        with framework.cuda.device(device), framework.inference_mode():
            properties = framework.cuda.get_device_properties(ordinal)
            if (framework.cuda.current_device() != ordinal
                    or _runtime_pci(ordinal, properties) != physical_binding["pci_bus_id"]):
                return None
            inputs = [secrets.randbits(30) for _ in range(3)]
            source = framework.tensor(inputs, dtype=framework.int32, device=device)
            result, events, _ = capture_trace(framework, device, lambda: framework.bitwise_not(source))
            if source.device != device or result.device != device or result.dtype != framework.int32:
                return None
            return proof_from_events(events, ordinal, physical_binding, inputs, result.cpu().tolist())
    except (OSError, ValueError, TypeError, AttributeError, RuntimeError):
        return None
