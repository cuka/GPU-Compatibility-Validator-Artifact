"""Offline release verification. The same standard-library file is the field bootstrap."""
from __future__ import annotations

import argparse
import hashlib
from functools import wraps
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

PART_SIZE = 16 * 1024 * 1024
MANIFEST = "release-manifest.json"
ALGORITHM = "RSA-PKCS1-v1_5-SHA256"
DOMAIN = b"compute-audit.signature.v1\x00"
IO_SIZE = 1024 * 1024
LEGACY_FIELD_FILES = frozenset((
    "__init__.py", "__main__.py", "artifacts.py", "challenge.py", "cli.py", "config.py",
    "contracts.py", "field_verifier.py", "inventory.py", "operators.py", "probe.py",
    "public_results.py", "reference.py", "release_verify.py", "runner.py", "validate_op.py",
    "worker.py", "data/defaults.json", "compute_audit_native.so",
))
FIELD_FILES = LEGACY_FIELD_FILES | {"kineto_binding.py", "kineto_copy.py"}


class ReleaseError(ValueError):
    """An invalid release, trust anchor or installation."""


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(IO_SIZE), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ReleaseError(f"MANIFEST_INVALID duplicate JSON key {key}")
            result[key] = value
        return result

    def invalid(value):
        raise ReleaseError(f"MANIFEST_INVALID invalid number {value}")

    try:
        return json.loads(Path(path).read_bytes(), object_pairs_hook=unique, parse_constant=invalid)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ReleaseError(f"MANIFEST_INVALID invalid JSON {path}") from exc


def safe_path(root, relative):
    if not isinstance(relative, str) or not relative or "\\" in relative or "\x00" in relative:
        raise ReleaseError(f"MANIFEST_INVALID invalid path {relative!r}")
    parts = relative.split("/")
    if any(part in ("", ".", "..") for part in parts):
        raise ReleaseError(f"MANIFEST_INVALID invalid path {relative!r}")
    root = Path(root).resolve()
    candidate = root.joinpath(*parts)
    if candidate.resolve() != candidate:
        raise ReleaseError(f"MANIFEST_INVALID unexpected symlink {relative}")
    return candidate


def signature_message(role, filename, content):
    return DOMAIN + role.encode("ascii") + b"\x00" + filename.encode("utf-8") + b"\x00" + content


def openssl(args, data=None):
    tool = shutil.which("openssl", path=os.defpath) or shutil.which("openssl")
    if tool is None:
        raise ReleaseError("OpenSSL is required for offline signature verification")
    result = subprocess.run([tool, *args], input=data, capture_output=True)
    if result.returncode:
        raise ReleaseError(f"SIGNATURE_INVALID {result.stderr.decode(errors='replace').strip()}")
    return result.stdout


def trust_key_id(trust_key):
    canonical = openssl(["rsa", "-pubin", "-in", str(Path(trust_key).resolve()), "-pubout", "-outform", "DER"])
    return hashlib.sha256(canonical).hexdigest()


def verify_signed_file(root, filename, role, trust_key):
    payload = safe_path(root, filename)
    signature = safe_path(root, filename + ".sig")
    openssl(["dgst", "-sha256", "-verify", str(Path(trust_key).resolve()), "-signature", str(signature),
             "-sigopt", "rsa_padding_mode:pkcs1"], signature_message(role, filename, payload.read_bytes()))


def all_files(root):
    names = []
    for entry in Path(root).rglob("*"):
        if entry.is_symlink():
            raise ReleaseError(f"MANIFEST_INVALID unexpected link {entry}")
        if entry.is_file():
            names.append(entry.relative_to(root).as_posix())
        elif not entry.is_dir():
            raise ReleaseError(f"MANIFEST_INVALID invalid file type {entry}")
    return sorted(names)


def material_roles(root):
    root = Path(root)
    parameter = safe_path(root, "parameters/parameters.json")
    if not parameter.is_file():
        raise ReleaseError("MANIFEST_INVALID missing parameter declaration")
    return {"parameters/parameters.json": "parameters"}


def check_parts(root, meta, output=None):
    parts = meta["parts"]
    if meta["part_size"] != PART_SIZE or not isinstance(parts, list) or not parts:
        raise ReleaseError("MANIFEST_INVALID invalid volume list")
    total = 0
    digest = hashlib.sha256()
    for i, item in enumerate(parts):
        name = f"environment.tar.gz.part{i + 1:05d}"
        size = item["size"]
        if item["path"] != name or type(size) is not int or not 0 < size <= PART_SIZE:
            raise ReleaseError(f"MANIFEST_INVALID invalid volume {name}")
        if i < len(parts) - 1 and size != PART_SIZE:
            raise ReleaseError(f"MANIFEST_INVALID short intermediate volume {name}")
        part = safe_path(root, name)
        if part.stat().st_size != size:
            raise ReleaseError(f"MANIFEST_INVALID volume size differs {name}")
        part_digest = hashlib.sha256()
        with part.open("rb") as stream:
            for chunk in iter(lambda: stream.read(IO_SIZE), b""):
                part_digest.update(chunk)
                digest.update(chunk)
                if output is not None:
                    output.write(chunk)
        if part_digest.hexdigest() != item["sha256"]:
            raise ReleaseError(f"MANIFEST_INVALID corrupt volume {name}")
        total += size
    if total != meta["size"] or digest.hexdigest() != meta["sha256"]:
        raise ReleaseError("MANIFEST_INVALID assembled environment digest differs")


def checked(operation):
    @wraps(operation)
    def guard(*args, **kwargs):
        try:
            return operation(*args, **kwargs)
        except ReleaseError:
            raise
        except (KeyError, OSError, TypeError, ValueError, IndexError, AttributeError, subprocess.CalledProcessError) as exc:
            raise ReleaseError(f"RELEASE_CHECK_ERROR {exc}") from exc
    return guard


@checked
def verify_release(release_dir, trust_key, expected_sha256):
    """Verify external trust, signed materials, exact tree and the logical archive."""
    root = Path(release_dir).resolve()
    manifest = safe_path(root, MANIFEST)
    if not re.fullmatch("[0-9a-f]{64}", expected_sha256 or "") or sha256_file(manifest) != expected_sha256:
        raise ReleaseError("MANIFEST_INVALID expected release digest differs")
    verify_signed_file(root, MANIFEST, "release", trust_key)
    doc = read_json(manifest)
    if doc.get("schema") != "compute_audit.release.v2" or doc.get("signature_algorithm") != ALGORITHM:
        raise ReleaseError("MANIFEST_INVALID unsupported release schema or signing protocol")
    if trust_key_id(trust_key) != doc.get("key_id"):
        raise ReleaseError("TRUST_KEY_UNKNOWN external release key differs")
    rows = doc["files"]
    actual = set(all_files(root)) - {MANIFEST, MANIFEST + ".sig"}
    names = {row["path"] for row in rows}
    if names != actual or len(rows) != len(names):
        raise ReleaseError("MANIFEST_INVALID unexpected, duplicate or missing files")
    mandatory = {"bootstrap.py", "install.sh", "verify-release.sh", "run.sh", "README_现场运行.md",
                 "installation-baseline.json", "build-provenance.json", "platform.json", "environment-parts.json",
                 "sbom.json", "candidate.json", "release-public.pem",
                 "parameters/parameters.json", "evidence/qualification.json"}
    if not mandatory <= names or not all(any(n.startswith(p) for n in names) for p in ("licenses/", "profiles/", "locks/")):
        raise ReleaseError("MANIFEST_INVALID required release materials missing")
    for name in names - mandatory:
        if (name == "parameters/parameters.json.sig" or re.fullmatch(r"environment\.tar\.gz\.part[0-9]{5}", name)
                or re.fullmatch(r"profiles/[^/]+\.json", name) or name.startswith(("licenses/", "locks/", "evidence/"))):
            continue
        raise ReleaseError("MANIFEST_INVALID unexpected field release material")
    if trust_key_id(root / "release-public.pem") != doc["key_id"]:
        raise ReleaseError("TRUST_KEY_UNKNOWN bundled public key differs from external trust key")
    material = material_roles(root)
    if doc["signed_materials"] != material:
        raise ReleaseError("MANIFEST_INVALID unexpected signed materials")
    archive = doc["environment"]
    if archive != read_json(root / "environment-parts.json"):
        raise ReleaseError("MANIFEST_INVALID volume index differs")
    volumes = {item["path"]: item for item in archive["parts"]}
    if not set(volumes) <= names:
        raise ReleaseError("MANIFEST_INVALID unlisted environment volume")
    for row in rows:
        name = row["path"]
        path = safe_path(root, name)
        if name in volumes:
            if row != volumes[name]:
                raise ReleaseError(f"MANIFEST_INVALID inconsistent volume metadata {name}")
        elif path.stat().st_size != row["size"] or sha256_file(path) != row["sha256"]:
            raise ReleaseError(f"MANIFEST_INVALID file mismatch {name}")
    check_parts(root, archive)
    for filename, role in material.items():
        verify_signed_file(root, filename, role, trust_key)
    candidate = read_json(root / "candidate.json")
    baseline = read_json(root / "installation-baseline.json")
    valid_layouts = [{baseline["package"] + "/" + name for name in files} for files in (FIELD_FILES, LEGACY_FIELD_FILES)]
    if {row["path"] for row in baseline["files"]} not in valid_layouts:
        raise ReleaseError("MANIFEST_INVALID installed project layout differs")
    native_path = baseline["package"] + "/compute_audit_native.so"
    native = [row["sha256"] for row in baseline["files"] if row["path"] == native_path]
    parameters = sha256_file(root / "parameters/parameters.json")
    if (candidate.get("validator_abi") != "3.1" or native != [candidate.get("native_sha256")]
            or not re.fullmatch("[0-9a-f]{64}", native[0]) or candidate.get("parameters_sha256") != parameters):
        raise ReleaseError("MANIFEST_INVALID candidate binding differs")
    return {"native_sha256": native[0], "parameters_sha256": parameters, "release_sha256": expected_sha256, "platform_id": doc["platform_id"],
            "source_commit": doc["source_commit"], "key_id": doc["key_id"], "tested_card_counts": doc["tested_card_counts"]}


def guard_files(prefix, signed):
    package_root = safe_path(prefix, signed["package"])
    files = {r["path"]: r["sha256"] for r in signed["files"]}
    actual = set()
    for path in package_root.rglob("*"):
        if "__pycache__" in path.parts:
            continue
        if path.is_file() or path.is_symlink():
            actual.add(path.relative_to(prefix).as_posix())
    if not actual or actual != set(files):
        raise ReleaseError("INSTALLATION_INVALID installed project file set differs")
    for name, digest in files.items():
        if sha256_file(safe_path(prefix, name)) != digest:
            raise ReleaseError(f"INSTALLATION_INVALID installed file differs {name}")
    python_file = safe_path(prefix, signed["python_file"])
    if (Path(prefix) / "bin/python").resolve() != python_file or sha256_file(python_file) != signed["python_sha256"]:
        raise ReleaseError("INSTALLATION_INVALID interpreter differs")


def host_compatibility(root):
    host = read_json(root / "platform.json")
    if host["system"] != platform.system() or host["machine"] != platform.machine():
        raise ReleaseError("UNSUPPORTED host OS or architecture differs from platform matrix")
    if host["glibc"] != platform.libc_ver()[1]:
        raise ReleaseError("UNSUPPORTED host glibc differs from measured target")
    for marker in host["host_runtime_files"]:
        if sha256_file(marker["path"]) != marker["sha256"]:
            raise ReleaseError(f"UNSUPPORTED external runtime differs {marker['path']}")
    return host


def field_env(root, prefix):
    host = host_compatibility(root)
    package = read_json(root / "installation-baseline.json")["package"]
    external = host["external_library_roots"]
    if not isinstance(external, list) or not all(isinstance(p, str) and Path(p).is_absolute() for p in external):
        raise ReleaseError("MANIFEST_INVALID invalid external library roots")
    libs = [str(prefix / "lib"), str(prefix / Path(package).parent / "torch/lib"), *external]
    env = {k: v for k, v in os.environ.items() if not k.startswith(("PYTHON", "LD_", "DYLD_"))}
    env.pop("COMPUTE_AUDIT_NATIVE_LIBRARY", None)
    env.update(PATH=f"{prefix}/bin:{os.defpath}", LD_LIBRARY_PATH=os.pathsep.join(libs), PYTHONNOUSERSITE="1")
    return env


def loaded_runtime(root, prefix):
    baseline = read_json(root / "installation-baseline.json")
    package = safe_path(prefix, baseline["package"])
    code = """
import ctypes, hashlib, json, pathlib, sys
sys.path.insert(0, sys.argv[1])
import compute_audit, compute_audit.field_verifier, torch
extension = pathlib.Path(compute_audit.__file__).parent / "compute_audit_native.so"
torch.ops.load_library(str(extension))
str(torch.ops.compute_audit.validate_compute.default._schema)
if torch.ops.compute_audit._validator_abi() != "3.1": raise SystemExit("unsupported operator ABI")
modules = [compute_audit.__file__, compute_audit.field_verifier.__file__, torch.__file__, str(extension)]
maps = set()
for line in pathlib.Path('/proc/self/maps').read_text().splitlines():
    fields = line.split(None, 5)
    if len(fields) == 6 and fields[1].find('x') != -1 and fields[5].startswith('/'):
        maps.add(str(pathlib.Path(fields[5]).resolve()))
print(json.dumps({'module_files': modules, 'torch_version': str(torch.__version__), 'libraries': sorted(maps)}))
"""
    proc = subprocess.run([str(prefix / "bin/python"), "-I", "-B", "-X", "pycache_prefix=/dev/null", "-S",
                           "-c", code, str(package.parent)], env=field_env(root, prefix), cwd=str(prefix),
                          capture_output=True, text=True)
    if proc.returncode:
        raise ReleaseError("INSTALLATION_INVALID framework or extension load failed")
    runtime = json.loads(proc.stdout.strip().splitlines()[-1])
    expected = [package / "__init__.py", package / "field_verifier.py",
                package.parent / "torch/__init__.py", package / "compute_audit_native.so"]
    if [Path(p).resolve() for p in runtime["module_files"]] != expected:
        raise ReleaseError("INSTALLATION_INVALID imported module origin differs")
    host = host_compatibility(root)
    if runtime["torch_version"] != host["torch_version"]:
        raise ReleaseError("INSTALLATION_INVALID actual PyTorch version differs")
    allowed = [prefix, *(Path(p).resolve() for p in host["external_library_roots"])]
    for lib in runtime["libraries"]:
        if not any(Path(lib).is_relative_to(p) for p in allowed):
            raise ReleaseError(f"INSTALLATION_INVALID external library outside platform matrix {lib}")
    # The independently kept install record pins the observed post-relocation bytes.
    observed = set(runtime["libraries"]) | set(runtime["module_files"])
    runtime["loaded_sha256"] = {str(p): sha256_file(p) for p in sorted(observed)}
    return runtime


@checked
def verify_installation(release_dir, trust_key, expected_sha256, install_record):
    result = verify_release(release_dir, trust_key, expected_sha256)
    root = Path(release_dir).resolve()
    record_path = Path(install_record).resolve()
    record = read_json(record_path)
    if record["release_sha256"] != expected_sha256:
        raise ReleaseError("INSTALLATION_INVALID record belongs to another release")
    prefix = Path(record["prefix"]).resolve()
    if prefix.is_relative_to(root) or record_path.is_relative_to(prefix) or record_path.is_relative_to(root):
        raise ReleaseError("INSTALLATION_INVALID installation and records must be outside release")
    guard_files(prefix, read_json(root / "installation-baseline.json"))
    saved = record["loaded_runtime"]
    paths = set(saved["module_files"]) | set(saved["libraries"])
    if not paths or paths != set(saved["loaded_sha256"]):
        raise ReleaseError("INSTALLATION_INVALID incomplete installation record")
    for path in paths:
        if sha256_file(path) != saved["loaded_sha256"][path]:
            raise ReleaseError(f"INSTALLATION_INVALID loaded dependency changed {path}")
    runtime = loaded_runtime(root, prefix)
    if runtime != saved:
        raise ReleaseError("INSTALLATION_INVALID loaded modules or dependencies changed")
    return {**result, "prefix": str(prefix), "loaded_runtime": runtime}


def unpack_environment(archive, prefix):
    if not hasattr(tarfile, "data_filter"):
        raise ReleaseError("Install requires a host Python with tarfile.data_filter")
    with tarfile.open(archive, "r:gz") as tar:
        members = set()
        for entry in tar:
            name = PurePosixPath(entry.name)
            if name.is_absolute() or ".." in name.parts or name in members:
                raise ReleaseError(f"INSTALLATION_INVALID invalid or duplicate archive entry {entry.name}")
            members.add(name)
            tar.extract(entry, path=prefix, filter="data")


def install(root, trust, expected, prefix, record_path):
    result = verify_release(root, trust, expected)
    archive_meta = read_json(root / MANIFEST)["environment"]
    return install_payload(root, archive_meta, prefix, record_path, result)


def install_payload(root, archive_meta, prefix, record_path, result):
    host_compatibility(root)
    if prefix.is_relative_to(root) or record_path.is_relative_to(prefix) or record_path.is_relative_to(root):
        raise ReleaseError("INSTALLATION_INVALID use distinct external locations")
    if prefix.exists() or record_path.exists():
        raise ReleaseError("INSTALLATION_INVALID choose a new prefix and installation record")
    with tempfile.TemporaryDirectory(dir=prefix.parent) as temp:
        archive = Path(temp) / "environment.tar.gz"
        with archive.open("xb") as output:
            check_parts(root, archive_meta, output)
        prefix.mkdir()
        unpack_environment(archive, prefix)
    baseline = read_json(root / "installation-baseline.json")
    guard_files(prefix, baseline)
    python = prefix / "bin/python"
    subprocess.run([str(python), "-I", "-B", str(prefix / "bin/conda-unpack")], cwd=prefix, check=True,
                   env=field_env(root, prefix))
    guard_files(prefix, baseline)
    runtime = loaded_runtime(root, prefix)
    with record_path.open("x") as record:
        json.dump({**result, "schema": "compute_audit.installation.v1", "prefix": str(prefix),
                   "prefix_repair": "conda-unpack", "loaded_runtime": runtime}, record, indent=2)
        record.write("\n")
    return {**result, "prefix": str(prefix), "install_record": str(record_path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["verify", "install", "run"])
    parser.add_argument("--release", type=Path, required=True)
    parser.add_argument("--trust-key", type=Path, required=True)
    parser.add_argument("--expect-sha256", required=True)
    parser.add_argument("--prefix", type=Path)
    parser.add_argument("--record", type=Path)
    # CLI arguments after the explicit delimiter belong to compute-audit.
    args = sys.argv[1:]
    cut = args.index("--") if "--" in args else len(args)
    opts = parser.parse_args(args[:cut])
    extra = args[cut + 1:]
    root, trust = opts.release.resolve(), opts.trust_key.resolve()
    if opts.action != "run" and extra:
        parser.error("unexpected compute-audit arguments")
    if opts.action == "verify":
        result = verify_release(root, trust, opts.expect_sha256)
    elif opts.action == "install":
        if opts.prefix is None:
            parser.error("install requires --prefix")
        prefix = opts.prefix.resolve()
        record = (opts.record or Path(str(prefix) + ".installation-record.json")).resolve()
        result = install(root, trust, opts.expect_sha256, prefix, record)
    else:
        if opts.record is None or not extra:
            parser.error("run requires --record and a compute-audit command following --")
        record = opts.record.resolve()
        result = verify_installation(root, trust, opts.expect_sha256, record)
        prefix = Path(result["prefix"])
        site = safe_path(prefix, read_json(root / "installation-baseline.json")["package"]).parent
        env = field_env(root, prefix)
        env.update(COMPUTE_AUDIT_RELEASE_DIR=str(root), COMPUTE_AUDIT_TRUST_KEY=str(trust),
                   COMPUTE_AUDIT_RELEASE_SHA256=opts.expect_sha256, COMPUTE_AUDIT_INSTALL_RECORD=str(record))
        launcher = "import runpy,sys;sys.path.insert(0,sys.argv.pop(1));runpy.run_module('compute_audit',run_name='__main__')"
        python = str(prefix / "bin/python")
        os.execve(python, [python, "-I", "-B", "-X", "pycache_prefix=/dev/null", "-S", "-c", launcher, str(site), *extra], env)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except (ReleaseError, OSError, KeyError, ValueError, subprocess.CalledProcessError, tarfile.TarError) as exc:
        if sys.argv[1:2] == ["run"]:
            print("Execution failed", file=sys.stderr)
        else:
            print(f"release verification failed: {exc}", file=sys.stderr)
        sys.exit(30)
