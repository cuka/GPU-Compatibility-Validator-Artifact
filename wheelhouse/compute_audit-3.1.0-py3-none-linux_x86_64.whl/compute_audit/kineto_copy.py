"""Collect and verify the narrowly defined device-copy path of the G4 addmm case."""

import math
import re

import numpy as np


_CPU_OP = "aten::addmm"
_HIP_COPY = "hipMemcpyAsync"
_GPU_COPY = "Memcpy DtoD (Device -> Device)"
G4_SHAPES = {"a": (7, 11), "b": (11, 5), "c": (7, 5)}
_DTYPES = {"float32": np.dtype("float32"), "float16": np.dtype("float16"), "bfloat16": np.dtype("uint16")}
_SPAN_KEYS = {"pid", "tid", "start_us", "duration_us", "external_id"}
_PROOF_KEYS = {"raw_device", "raw_stream", "start_us", "duration_us", "cpu", "launch", "gpu"}


def _case_dtype(call, operator_args):
    if not isinstance(call, dict) or call.get("case_id") != "G4" or not isinstance(operator_args, dict):
        return None
    if (operator_args.keys() != {"alpha", "beta"} or type(operator_args["alpha"]) is not int
            or type(operator_args["beta"]) is not int or operator_args != {"alpha": 0, "beta": 1}):
        return None
    dtype = call.get("dtype")
    return _DTYPES.get(dtype) if isinstance(dtype, str) else None


def _uint(value, *, positive=False):
    return type(value) is int and value >= int(positive)


def _time(value):
    if type(value) is int:
        return 0 <= value <= (1 << 53) - 1
    return type(value) is float and math.isfinite(value) and value >= 0


def _span_ok(span):
    return (_uint(span["pid"]) and _uint(span["tid"]) and _uint(span["external_id"], positive=True)
            and _time(span["start_us"]) and _time(span["duration_us"]) and span["duration_us"] > 0)


def _anchors_match(proof, size):
    if type(proof) is not dict or proof.keys() != _PROOF_KEYS:
        return False
    cpu, launch, gpu = proof["cpu"], proof["launch"], proof["gpu"]
    if (not _uint(proof["raw_device"]) or not _uint(proof["raw_stream"])
            or not _time(proof["start_us"]) or not _time(proof["duration_us"]) or proof["duration_us"] <= 0
            or type(cpu) is not dict or cpu.keys() != _SPAN_KEYS | {"cat", "name"}
            or type(launch) is not dict or launch.keys() != _SPAN_KEYS | {"cat", "name", "kind", "correlation",
                                                                          "src", "dst", "bytes"}
            or type(gpu) is not dict or gpu.keys() != {"cat", "name", "kind", "external_id", "correlation", "bytes"}):
        return False
    if (cpu["cat"] != "cpu_op" or cpu["name"] != _CPU_OP or launch["cat"] != "cuda_runtime"
            or launch["name"] != _HIP_COPY or launch["kind"] != "3" or (launch["src"], launch["dst"]) != ("C", "output")
            or gpu["cat"] != "gpu_memcpy" or gpu["name"] != _GPU_COPY or gpu["kind"] != "DtoD"):
        return False
    return (_span_ok(cpu) and _span_ok(launch)
            and (cpu["pid"], cpu["tid"]) == (launch["pid"], launch["tid"])
            and _uint(gpu["external_id"], positive=True)
            and cpu["external_id"] == launch["external_id"] == gpu["external_id"]
            and _uint(launch["correlation"], positive=True) and _uint(gpu["correlation"], positive=True)
            and launch["correlation"] == gpu["correlation"]
            and launch["bytes"] == str(size) and _uint(gpu["bytes"]) and gpu["bytes"] == size
            and cpu["start_us"] <= launch["start_us"]
            and launch["start_us"] + launch["duration_us"] <= cpu["start_us"] + cpu["duration_us"]
            and proof["start_us"] >= launch["start_us"])


def _live_buffers(data, output, dtype):
    if not isinstance(data, dict) or data.keys() != G4_SHAPES.keys():
        return None
    for name, value in (*data.items(), ("c", output)):
        if (not value.is_cuda or value.device != output.device or not value.is_contiguous()
                or str(value.dtype).removeprefix("torch.") != dtype or tuple(value.shape) != G4_SHAPES[name]):
            return None
    source = data["c"]
    if (source.untyped_storage().data_ptr() == output.untyped_storage().data_ptr()
            or source.numel() != 35 or output.numel() != 35
            or source.element_size() != _DTYPES[dtype].itemsize or output.element_size() != _DTYPES[dtype].itemsize):
        return None
    src, dst = source.data_ptr(), output.data_ptr()
    return (src, dst) if _uint(src, positive=True) and _uint(dst, positive=True) and src != dst else None


def _pointer(value):
    if _uint(value, positive=True):
        return value
    if isinstance(value, str) and re.fullmatch(r"0x[0-9a-fA-F]{1,16}", value):
        return int(value, 16)
    return None


def _span(event):
    return {"name": event["name"], "cat": event["cat"], "pid": event.get("pid"), "tid": event.get("tid"),
            "start_us": event.get("ts"), "duration_us": event.get("dur"),
            "external_id": event["args"].get("External id")}


def collect_g4_copy(events, call, args, result, raw_device, raw_stream):
    """Bind a completed copy to the live C and result. Persist labels instead of their addresses."""
    if not isinstance(args, tuple) or len(args) != 2:
        return None
    data, operator_args = args
    dtype = _case_dtype(call, operator_args)
    if dtype is None or not _uint(raw_device) or not _uint(raw_stream) or not isinstance(events, list):
        return None
    try:
        buffers = _live_buffers(data, result, call["dtype"])
    except (AttributeError, TypeError, RuntimeError, ValueError):
        return None
    if buffers is None:
        return None

    spans = [e for e in events if isinstance(e, dict) and e.get("ph") == "X" and isinstance(e.get("args"), dict)]
    operators = [e for e in spans if e.get("cat") == "cpu_op" and e.get("name") == _CPU_OP]
    if len(operators) != 1:
        return None
    cpu = _span(operators[0])
    if not _span_ok(cpu):
        return None
    launches = [e for e in spans if e.get("cat") == "cuda_runtime" and e.get("name") == _HIP_COPY
                and e["args"].get("External id") == cpu["external_id"]]
    if len(launches) != 1:
        return None
    launch_event = launches[0]
    meta = launch_event["args"]
    if (_pointer(meta.get("src")), _pointer(meta.get("dst"))) != buffers:
        return None
    launch = _span(launch_event) | {"src": "C", "dst": "output", "kind": meta.get("kind"),
                                    "bytes": meta.get("bytes"), "correlation": meta.get("correlation")}
    if not _uint(launch["correlation"], positive=True):
        return None
    copies = [e for e in spans if e.get("cat") == "gpu_memcpy" and e["args"].get("correlation") == launch["correlation"]]
    if len(copies) != 1:
        return None
    copy = copies[0]
    gpu_meta = copy["args"]
    if (not _uint(gpu_meta.get("device")) or not _uint(gpu_meta.get("stream"))
            or (gpu_meta["device"], gpu_meta["stream"]) != (raw_device, raw_stream)):
        return None
    gpu = {"cat": copy.get("cat"), "name": copy.get("name"), "kind": gpu_meta.get("kind"),
           "bytes": gpu_meta.get("bytes"), "external_id": gpu_meta.get("External id"),
           "correlation": gpu_meta["correlation"]}
    proof = {"raw_device": raw_device, "raw_stream": raw_stream, "start_us": copy.get("ts"),
             "duration_us": copy.get("dur"), "cpu": cpu, "launch": launch, "gpu": gpu}
    return proof if _anchors_match(proof, dtype.itemsize * 35) else None


def validate_g4_copy(proof, call, args, actual):
    """Independently compare the archived unrounded bytes and recheck the sanitized trace anchors."""
    if not isinstance(args, tuple) or len(args) != 2:
        return False
    c_bits, operator_args = args
    dtype = _case_dtype(call, operator_args)
    if (dtype is None or not isinstance(c_bits, np.ndarray) or not isinstance(actual, np.ndarray)
            or c_bits.dtype != dtype or actual.dtype != dtype
            or c_bits.shape != G4_SHAPES["c"] or actual.shape != c_bits.shape):
        return False
    if dtype == np.dtype("uint16"):
        if ((c_bits & 0x7f80) == 0x7f80).any():  # Nonfinite BF16 inputs are outside G4.
            return False
    elif not np.isfinite(c_bits).all():
        return False
    return _anchors_match(proof, actual.nbytes) and c_bits.tobytes() == actual.tobytes()
