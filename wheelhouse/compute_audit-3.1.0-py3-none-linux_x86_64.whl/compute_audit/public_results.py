"""Allowlisted, ordinal-only public run results. Detailed audit data stays in the private bundle."""
from __future__ import annotations

import csv
import io
import tempfile
from pathlib import Path

from .contracts import AuditError, Exit, canonical, digest, load


OPERATORS = ("GEMM", "RMSNorm", "SDPA", "Validate Compute")
RUN_STATES = frozenset(Exit.__members__)
OP_STATES = RUN_STATES | {"NOT_RUN"}
SCOPES = {"smoke", "conformance", "acceptance", "selftest", "preflight"}
COVERAGE = ("total", "completed", "passed")
RESULT_FILES = ("report.json", "report.md", "device-results.csv", "events.jsonl")
PUBLIC_FILES = {*RESULT_FILES, "manifest.json"}
LEGACY_LAYOUT = "public_integrity_v1"
PUBLIC_LAYOUT = "public_integrity_v2"

_OPERATOR_LABELS = {"GEMM": "矩阵乘加", "RMSNorm": "均方根归一化", "SDPA": "缩放点积注意力", "Validate Compute": "计算校验"}
_STATUS_LABELS = {"PASS": "通过", "FAIL": "不通过", "INCOMPLETE": "检测不完整",
                  "ERROR": "执行失败", "UNSUPPORTED": "不支持", "NOT_RUN": "未执行"}


def operator_label(operator):
    return _OPERATOR_LABELS[operator]


def status_label(status):
    return _STATUS_LABELS[status]


def card_label(ordinal):
    return f"第 {ordinal} 张卡"


def _invalid():
    raise AuditError("PUBLIC_RESULT_INVALID")


def _choice(value, choices):
    if not isinstance(value, str) or value not in choices:
        _invalid()
    return value


def _counts(value):
    if not isinstance(value, dict):
        _invalid()
    out = {field: value.get(field) for field in COVERAGE}
    if any(type(x) is not int for x in out.values()) or not 0 <= out["passed"] <= out["completed"] <= out["total"]:
        _invalid()
    return out


def _op(value):
    status = _choice(value, OP_STATES)
    return {"status": status, "message": "执行失败"} if status in {"ERROR", "FAIL"} else {"status": status}


def _report(scope, status, devices, *, skip_device_fp64=False):
    _choice(scope, SCOPES)
    _choice(status, RUN_STATES)
    if type(skip_device_fp64) is not bool or (skip_device_fp64 and scope not in {"conformance", "selftest"}):
        _invalid()
    total = {key: sum(row["required"][key] for row in devices) for key in COVERAGE}
    for row in devices:
        if row["status"] == "PASS":
            op_states = {op["status"] for op in row["operators"].values()}
            if (row["required"]["total"] == 0 or row["required"]["passed"] != row["required"]["total"]
                    or "PASS" not in op_states or op_states - {"PASS", "NOT_RUN"}):
                _invalid()
    if scope in ("smoke", "preflight") and devices:
        _invalid()
    if status == "PASS" and scope != "smoke" and (not devices or any(r["status"] != "PASS" for r in devices)):
        _invalid()
    report = {"schema_version": "3.0", "report_kind": "public_run", "scope": scope,
              "declared_run_status": status, "acceptance_eligible": False,
              "device_count": len(devices), "required": total, "devices": devices}
    if skip_device_fp64:
        report["skip_device_fp64"] = True
    return report


def _status_name(status):
    return _choice(status.name if isinstance(status, Exit) else status, RUN_STATES)


def project_report(private_report, status=None):
    """Project a trusted private report; ordinals are positions inside this run only."""
    if not isinstance(private_report, dict):
        _invalid()
    declared = private_report.get("declared_run_status")
    status = _status_name(declared if status is None else status)
    if declared is not None and declared != status:
        _invalid()
    kind = private_report.get("report_kind")
    _choice(kind, {"run", "selftest", "device_replay", "probe"})
    scope = ("preflight" if kind == "probe" else "selftest" if kind == "selftest"
             else _choice(private_report.get("scope"), SCOPES))
    private_devices = private_report.get("devices", [])
    if not isinstance(private_devices, list):
        _invalid()
    devices = []
    for ordinal, item in enumerate(private_devices, start=1):
        if not isinstance(item, dict):
            _invalid()
        devices.append({"gpu": ordinal, "status": _choice(item.get("status"), RUN_STATES),
                        "required": _counts({k: item.get("required_" + k) for k in COVERAGE}),
                        "operators": {name: _op(item.get(name)) for name in OPERATORS}})
    report = _report(scope, status, devices, skip_device_fp64=private_report.get("skip_device_fp64", False))
    if "required" in private_report and _counts(private_report["required"]) != report["required"]:
        _invalid()
    return report


def _validate_report(doc):
    if not isinstance(doc, dict) or not isinstance(doc.get("devices"), list):
        _invalid()
    devices = []
    for ordinal, item in enumerate(doc["devices"], start=1):
        if not isinstance(item, dict) or type(item.get("gpu")) is not int or item["gpu"] != ordinal:
            _invalid()
        ops = item.get("operators")
        if not isinstance(ops, dict):
            _invalid()
        checked = {}
        for name in OPERATORS:
            if not isinstance(ops.get(name), dict):
                _invalid()
            checked[name] = _op(ops[name].get("status"))
        devices.append({"gpu": ordinal, "status": _choice(item.get("status"), RUN_STATES),
                        "required": _counts(item.get("required")), "operators": checked})
    expected = _report(doc.get("scope"), doc.get("declared_run_status"), devices,
                       skip_device_fp64=doc.get("skip_device_fp64", False))
    if canonical(doc) != canonical(expected):
        _invalid()
    return expected


def _public_bytes(report, *, version=PUBLIC_LAYOUT):
    legacy = version == LEGACY_LAYOUT
    scope_names = {"smoke": "CPU 自检" if legacy else "主机自检", "preflight": "运行预检", "selftest": "算子自检",
                   "conformance": "兼容性检测", "acceptance": "验收检测"}
    operators = OPERATORS if legacy else tuple(map(operator_label, OPERATORS))
    run_status = report["declared_run_status"]
    counted = report["required"]
    text = ["# 算力卡检测结果", "",
            f"{scope_names[report['scope']]}　**{run_status if legacy else status_label(run_status)}**", "",
            f"本轮 {report['device_count']} 张卡，必测完成 {counted['completed']}/{counted['total']}，通过 {counted['passed']}。", ""]
    skip_device_fp64 = report.get("skip_device_fp64", False)
    if skip_device_fp64:
        if legacy:
            _invalid()
        text.extend(["本轮已跳过 GPU FP64 检查，结果仅供诊断。", ""])
    if report["devices"]:
        text.extend(["| " + " | ".join(("算力卡", *operators, "必测通过", "结论")) + " |",
                     "| --- | --- | --- | --- | --- | --- | --- |"])
    table = io.StringIO(newline="")
    writer = csv.writer(table, lineterminator="\n")
    writer.writerow(("gpu", *operators, "required_total", "required_completed", "required_passed", "status") if legacy
                    else ("算力卡序号", *operators, "必测总数", "必测完成数", "必测通过数", "结论"))
    events = [{"event": "run_start", "device_count": report["device_count"]}]
    if skip_device_fp64:
        events[0]["skip_device_fp64"] = True
    for row in report["devices"]:
        gpu = row["gpu"]
        counts = row["required"]
        checks = [row["operators"][name] for name in OPERATORS]
        labels = [check.get("message") or (check["status"] if legacy else status_label(check["status"])) for check in checks]
        card = f"GPU-{gpu}" if legacy else card_label(gpu)
        conclusion = row["status"] if legacy else status_label(row["status"])
        text.append("| " + " | ".join([card, *labels, f"{counts['passed']}/{counts['total']}", conclusion]) + " |")
        writer.writerow([gpu, *labels, *(counts[k] for k in COVERAGE), conclusion])
        events.append({"event": "device_start", "gpu": gpu})
        events.extend({"event": "operator_result", "gpu": gpu, "operator": op, **row["operators"][op]} for op in OPERATORS)
        events.append({"event": "device_end", "gpu": gpu, "status": row["status"]})
    events.append({"event": "run_end", "status": report["declared_run_status"], "required": counted})
    return {"report.json": canonical(report) + b"\n", "report.md": ("\n".join(text) + "\n").encode(),
            "device-results.csv": table.getvalue().encode(), "events.jsonl": b"".join(canonical(e) + b"\n" for e in events)}


def _manifest(files, *, version=PUBLIC_LAYOUT):
    manifest = {"schema_version": version,
                "files": [{"path": n, "size": len(files[n]), "sha256": digest(files[n])} for n in RESULT_FILES]}
    return canonical(manifest) + b"\n"


def _source_report(source, status):
    report = source / "report.json"
    if report.is_file() and not report.is_symlink():
        try:
            data = load(report)
        except (OSError, TypeError, ValueError, UnicodeError):
            raise AuditError("PUBLIC_RESULT_INVALID") from None
        return project_report(data, status)
    if report.is_symlink():
        _invalid()
    # Early exits can precede private report creation. Their public coverage is empty.
    if status in {"UNSUPPORTED", "ERROR", "INCOMPLETE", "FAIL"}:
        return _report("preflight", status, [])
    _invalid()


def publish(source, destination, status):
    """Write a new standalone directory. Only newly constructed allowlisted bytes leave the private side."""
    source, destination = Path(source).resolve(), Path(destination).absolute()
    if destination.is_symlink() or destination.exists():
        raise AuditError("PUBLIC_OUTPUT_EXISTS")
    destination = destination.resolve()
    if source == destination or source.is_relative_to(destination) or destination.is_relative_to(source):
        raise AuditError("PUBLIC_AND_PRIVATE_PATHS_OVERLAP")
    report = _source_report(source, _status_name(status))
    files = _public_bytes(report)
    files["manifest.json"] = _manifest(files)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent) as temp:
        staging = Path(temp) / "result"
        staging.mkdir()
        for name, value in files.items():
            (staging / name).write_bytes(value)
        staging.rename(destination)
    return report


def verify_public(bundle):
    """Check exact public schema, four projections and their manifest; preserve the declared run status."""
    root = Path(bundle)
    try:
        if root.is_symlink() or not root.is_dir():
            _invalid()
        entries = list(root.iterdir())
        if {p.name for p in entries} != PUBLIC_FILES or any(p.is_symlink() or not p.is_file() for p in entries):
            _invalid()
        report = _validate_report(load(root / "report.json"))
        manifest = load(root / "manifest.json")
        if not isinstance(manifest, dict):
            _invalid()
        version = _choice(manifest.get("schema_version"), {LEGACY_LAYOUT, PUBLIC_LAYOUT})
        files = _public_bytes(report, version=version)
        files["manifest.json"] = _manifest(files, version=version)
        for name, expected in files.items():
            path = root / name
            if path.stat().st_size != len(expected) or path.read_bytes() != expected:
                _invalid()
    except (OSError, TypeError, ValueError, KeyError, UnicodeError):
        raise AuditError("PUBLIC_RESULT_INVALID") from None
    result = {"schema_version": "3.0", "report_kind": "verify", "verification_scope": "public_integrity",
              "verification_status": "PASS", "integrity_status": "PASS", "acceptance_eligible": False,
              "declared_run_status": report["declared_run_status"]}
    if report.get("skip_device_fp64"):
        result["skip_device_fp64"] = True
    return result


def assert_public_matches(bundle, source):
    """Compare a verified private bundle's permitted projection with its public report."""
    checked = verify_public(bundle)
    source = Path(source).resolve()
    if not any((source / name).is_file() and not (source / name).is_symlink() for name in ("report.json", "probe.json")):
        raise AuditError("PRIVATE_RESULT_UNAVAILABLE")
    expected = _source_report(source, checked["declared_run_status"])
    if (Path(bundle) / "report.json").read_bytes() != canonical(expected) + b"\n":
        raise AuditError("PUBLIC_PRIVATE_RESULT_MISMATCH")
    return checked


def project_verification(value):
    """Export status fields from a private review without copying identifiers, evidence, dates or messages."""
    if not isinstance(value, dict):
        _invalid()
    kind = _choice(value.get("report_kind", "verify"), {"verify", "reference_replay"})
    result = {"schema_version": "3.0", "report_kind": kind}
    allowed = {"verification_scope": {"full_numeric", "diagnostic_no_device_fp64", "integrity_only", "public_integrity"},
               "verification_status": {"PASS", "FAIL", "ERROR", "INCOMPLETE"},
               "integrity_status": {"PASS", "FAIL", "ERROR", "INCOMPLETE"},
               "declared_run_status": RUN_STATES, "recomputed_run_status": RUN_STATES, "final_status": RUN_STATES}
    for key, choices in allowed.items():
        if key in value:
            result[key] = _choice(value[key], choices)
    result["acceptance_eligible"] = (kind == "verify" and result.get("verification_scope") == "full_numeric"
                                     and value.get("custody_status") == "ANCHORED" and value.get("acceptance_eligible") is True
                                     and all(result.get(k) == "PASS" for k in ("integrity_status", "verification_status",
                                                                              "recomputed_run_status", "final_status")))
    return result
