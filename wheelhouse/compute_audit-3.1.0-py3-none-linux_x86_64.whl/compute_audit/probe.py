"""Read-only platform probing."""

import platform
import shutil
import sys
from pathlib import Path

import numpy

from .inventory import _run, snapshot


def probe():
    observed = snapshot()
    versions = {}
    for tool in ("hycc", "hipcc", "gcc", "c++", "cmake", "hy-smi", "rocprof"):
        path = shutil.which(tool)
        if path:
            versions[tool] = {"path": path, "version": _run(path, "--version").strip()[:1024]}
    for name in ("/opt/rocm/.info/version", "/opt/hyhal/.info/version"):
        if Path(name).is_file():
            versions[name] = Path(name).read_text().splitlines()[0]
    return {"schema_version": "3.0", "report_kind": "probe", "acceptance_eligible": False, "topology": observed,
            "os": platform.platform(), "machine": platform.machine(), "glibc": platform.libc_ver(),
            "python": sys.version, "python_path": sys.executable, "numpy": numpy.__version__, "tools": versions}
