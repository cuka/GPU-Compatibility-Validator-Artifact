"""Binary tensor evidence and append-only event sealing."""

import csv
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from .contracts import AuditError, canonical, digest, file_digest, load, parse, safe_path, write


STORAGE_TYPES = {"float64": "<f8", "float32": "<f4", "float16": "<f2", "bfloat16": "<u2",
                 "bool": "?", "int64": "<i8", "uint8": "u1"}


def tensor(root, relative, value):
    path = safe_path(root, relative)
    path.parent.mkdir(parents=True, exist_ok=True)
    device = str(value.device) if hasattr(value, "detach") else "cpu"
    if hasattr(value, "detach"):
        import torch

        dtype = str(value.dtype).split(".")[-1]
        strides, offset = tuple(value.stride()), value.storage_offset()
        host = value.detach().to("cpu").contiguous()
        array = host.view(torch.uint16).numpy() if dtype == "bfloat16" else host.numpy()
    else:
        array = np.asarray(value)
        dtype = array.dtype.name
        strides, offset = tuple(s // array.itemsize for s in array.strides), 0
    payload = array.astype(STORAGE_TYPES[dtype], copy=False).tobytes(order="C")
    temporary = path.with_name(path.name + ".partial")
    temporary.write_bytes(payload)
    temporary.replace(path)
    return {"path": relative, "dtype": dtype, "shape": list(array.shape), "strides": list(strides),
            "storage_offset": offset, "size": len(payload), "sha256": digest(payload), "device": device, "byte_order": "little"}


def read_tensor(root, metadata, limit, *, bits=False):
    shape, strides, offset = metadata["shape"], metadata["strides"], metadata["storage_offset"]
    kind = STORAGE_TYPES[metadata["dtype"]]
    itemsize = np.dtype(kind).itemsize
    count = 1
    if len(shape) != len(strides) or len(shape) > 16 or type(offset) is not int or offset < 0 or metadata["byte_order"] != "little":
        raise AuditError("TENSOR_LAYOUT_INVALID")
    for dim, stride in zip(shape, strides):
        if type(dim) is not int or type(stride) is not int or dim < 0 or stride < 0:
            raise AuditError("TENSOR_LAYOUT_INVALID")
        count *= dim
    extent = 1 + offset + sum(max(dim - 1, 0) * stride for dim, stride in zip(shape, strides))
    size = count * itemsize
    if size > limit or extent * itemsize > limit or size != metadata["size"]:
        raise AuditError("TENSOR_RESOURCE_LIMIT")
    path = safe_path(root, metadata["path"])
    if not path.is_file() or path.stat().st_size != size:
        raise AuditError("TENSOR_SIZE_INVALID")
    payload = path.read_bytes()
    if digest(payload) != metadata["sha256"]:
        raise AuditError("TENSOR_SHA256_INVALID")
    array = np.frombuffer(payload, dtype=kind).reshape(shape)
    if metadata["dtype"] == "bfloat16" and not bits:
        return (array.astype(np.uint32) << 16).view(np.float32)
    return array


def restore_tensor(root, metadata, limit):
    """Rebuild a bounded Torch CPU view from recorded logical bytes and layout."""
    import torch

    values = read_tensor(root, metadata, limit, bits=True)
    shape, strides, offset = metadata["shape"], metadata["strides"], metadata["storage_offset"]
    extent = 1 + offset + sum(max(dim - 1, 0) * stride for dim, stride in zip(shape, strides))
    backing = np.zeros(extent, dtype=values.dtype)
    logical = np.lib.stride_tricks.as_strided(backing[offset:], shape=shape,
                                                strides=tuple(s * values.itemsize for s in strides))
    logical[...] = values
    if logical.tobytes() != values.tobytes():
        raise AuditError("TENSOR_LAYOUT_CONFLICT")
    base = torch.from_numpy(backing)
    if metadata["dtype"] == "bfloat16":
        base = base.view(torch.bfloat16)
    return base.as_strided(shape, strides, offset)


def event_hash(event, previous):
    return digest(b"compute_audit_event_v1\n" + previous.encode("ascii") + b"\n" + canonical(event))


class Events:
    def __init__(self, path, run_id, plan_hash):
        self.stream = path.open("xb")
        self.run_id = run_id
        self.plan_hash = plan_hash
        self.seq = 0
        self.head = "0" * 64
        self.started = time.monotonic_ns()

    def emit(self, name, **params):
        self.seq += 1
        event = dict(seq=self.seq, event_type=name, run_id=self.run_id, plan_sha256=self.plan_hash,
                     utc=datetime.now(timezone.utc).isoformat(), monotonic_ns=time.monotonic_ns() - self.started, **params)
        self.head = event_hash(event, self.head)
        self.stream.write(canonical(event | {"event_hash": self.head}) + b"\n")
        self.stream.flush()

    def close(self):
        self.stream.close()


def jsonl(path, rows):
    with path.open("wb") as stream:
        for row in rows:
            stream.write(canonical(row) + b"\n")


def read_jsonl(path):
    with path.open("rb") as stream:
        for line in stream:
            if not line.endswith(b"\n"):
                raise AuditError(f"truncated JSONL file: {path.name}")
            yield parse(line)


def csv_rows(path, rows, columns):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def seal(root, plan, event_count, chain_head, complete):
    entries = []
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise AuditError("BUNDLE_SYMLINK")
        if path.is_file() and path.name != "manifest.json":
            entries.append({"path": path.relative_to(root).as_posix(), "size": path.stat().st_size, "sha256": file_digest(path)})
    write(root / "manifest.json", {"schema_version": "3.0", "plan_sha256": plan, "events": event_count,
                                   "event_chain_head": chain_head, "complete": complete, "files": entries})


def check_manifest(root):
    manifest = load(safe_path(root, "manifest.json"))
    if manifest["schema_version"] != "3.0" or type(manifest["complete"]) is not bool:
        raise AuditError("MANIFEST_INVALID")
    seen = set()
    for entry in manifest["files"]:
        path = safe_path(root, entry["path"])
        if entry["path"] in seen or entry["path"] == "manifest.json" or not path.is_file():
            raise AuditError("MANIFEST_INVALID")
        if path.stat().st_size != entry["size"] or file_digest(path) != entry["sha256"]:
            raise AuditError(f"EVIDENCE_DIGEST_INVALID: {entry['path']}")
        seen.add(entry["path"])
    for path in root.rglob("*"):
        if path.is_symlink() or (path.is_file() and path.relative_to(root).as_posix() not in seen | {"manifest.json"}):
            raise AuditError("UNLISTED_EVIDENCE")
    return manifest, seen
