"""Independent NumPy float64 mathematical and validator references."""

import numpy as np


def compare(actual, expected, atol, rtol, floor):
    actual = np.asarray(actual, dtype=np.float64)
    expected = np.asarray(expected, dtype=np.float64)
    counts = np.zeros(9, dtype=np.int64)
    counts[0] = actual.size
    metrics = np.full(4, np.nan)
    if not actual.size:
        return metrics, counts, 2
    counts[3:7] = [np.count_nonzero(m(x)) for x in (actual, expected) for m in (np.isnan, np.isinf)]
    pair = np.isfinite(actual) & np.isfinite(expected)
    counts[1] = np.count_nonzero(pair)
    values, reference = actual[pair], expected[pair]
    with np.errstate(all="ignore"):
        errors = np.abs(values - reference)
        scaled = rtol * np.abs(reference)
        limits = atol + scaled
        valid = np.isfinite(errors) & np.isfinite(scaled) & np.isfinite(limits)
        counts[2] = np.count_nonzero(valid & (errors > limits))
        counts[7] = np.count_nonzero(~valid)
        if counts[5] or counts[6]:
            return metrics, counts, 3
        if counts[7]:
            return metrics, counts, 4
        if counts[3] or counts[4]:
            return metrics, counts, 1
        maximum = np.max(errors)
        normalized = errors / maximum if maximum else np.zeros_like(errors)
        metrics[:] = (maximum, maximum * np.mean(normalized), maximum * np.sqrt(np.mean(normalized ** 2)),
                      np.max(errors / np.maximum(np.abs(reference), floor)))
        counts[8] = np.count_nonzero(~np.isfinite(metrics))
        metrics[~np.isfinite(metrics)] = np.nan
    return metrics, counts, 4 if counts[8] else int(counts[2] > 0)


def reference(case_id, values, args, block_rows=64):
    values = {k: np.asarray(v, dtype=np.float64) for k, v in values.items()}
    if case_id.startswith("G"):
        a, b, c = (values[k] for k in ("a", "b", "c"))
        alpha, beta = args["alpha"], args["beta"]
        if not beta:
            return alpha * (a @ b)
        if not alpha:
            return np.broadcast_to(beta * c, (a.shape[0], b.shape[-1])).copy()
        return alpha * (a @ b) + beta * c
    if case_id.startswith("R"):
        x = values["x"]
        axes = tuple(range(x.ndim - len(args["normalized_shape"]), x.ndim))
        return x / np.sqrt(np.mean(x * x, axis=axes, keepdims=True) + args["eps"]) * values["weight"]
    q, k, v = (values[x] for x in ("q", "k", "v"))
    if args["enable_gqa"]:
        k, v = (np.repeat(t, q.shape[-3] // t.shape[-3], axis=-3) for t in (k, v))
    chunks = []
    for offset in range(0, q.shape[-2], block_rows):
        stop = min(offset + block_rows, q.shape[-2])
        scores = (q[..., offset:stop, :] @ np.swapaxes(k, -1, -2)) * args["scale"]
        if args["is_causal"]:
            allowed = np.arange(k.shape[-2])[None, :] <= np.arange(offset, stop)[:, None]
            scores = np.where(allowed, scores, -np.inf)
        if "mask" in values:
            mask = values["mask"][..., offset:stop, :]
            scores = scores + mask if args["mask_type"] == "float" else np.where(mask, scores, -np.inf)
        exp = np.exp(scores - scores.max(axis=-1, keepdims=True))
        chunks.append((exp / exp.sum(axis=-1, keepdims=True)) @ v)
    return np.concatenate(chunks, axis=-2)


def numeric_vector(case_id):
    if case_id == "V1":
        return [1., -0., 0.], [1., 0., -0.], 0., 0
    if case_id == "V2":
        return [0., 3., 4.], [0., 0., 0.], 4., 0
    if case_id == "V3":
        return [np.nan, np.inf, 2.], [0., 1., 0.], 1., 1
    if case_id == "V4":
        return [0., 2.], [np.nan, 0.], 1., 3
    if case_id == "V5":
        return [], [], 0., 2
    return [1., np.nextafter(1., np.inf)], [0., 0.], 1., 1
