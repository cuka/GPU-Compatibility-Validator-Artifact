"""Versioned semantic input catalog and real PyTorch operator calls."""

import numpy as np


def make_inputs(case_id, seed, eps):
    rng = np.random.default_rng(np.random.SeedSequence([seed, ord(case_id[0]), int(case_id[1:])]))

    def values(*dims):
        return rng.normal(0, .5, dims).astype(np.float32)

    if case_id.startswith("G"):
        m, k, n = {"G1": (17, 23, 19), "G2": (17, 23, 19), "G3": (8, 8, 8), "G4": (7, 11, 5)}[case_id]
        a, b, c = values(m, k), values(k, n), values(m, n)
        alpha, beta = {"G1": (1, 1), "G2": (2, -1), "G3": (1, 0), "G4": (0, 1)}[case_id]
        if case_id == "G2":
            c = values(n)
        if case_id == "G3":
            b = np.eye(k, dtype=np.float32)
            c[0, :2] = (np.nan, np.inf)
        return {"a": a, "b": b, "c": c}, {"alpha": alpha, "beta": beta}
    if case_id.startswith("R"):
        if case_id == "R1":
            x, weight = values(2, 3, 17), 1 + values(17)
        elif case_id == "R2":
            x, weight = np.full((2, 3, 4, 5), 3., dtype=np.float32), 1 + values(4, 5)
        else:
            x, weight = np.repeat(np.array([[0.], [1e-4]], dtype=np.float32), 17, axis=1), np.ones(17, dtype=np.float32)
        return {"x": x, "weight": weight}, {"normalized_shape": list(weight.shape), "eps": eps}
    length, keys = {"S1": (7, 9), "S2": (4, 6), "S3": (4, 6), "S4": (7, 7),
                    "S5": (2, 5), "S6": (2, 5), "S7": (1, 5), "S8": (3, 5)}[case_id]
    heads = 4 if case_id == "S8" else 2
    q, k, v = values(1, heads, length, 8), values(1, 2, keys, 8), values(1, 2, keys, 5)
    if case_id != "S1":
        q.fill(0)
        k.fill(0)
        v = np.broadcast_to(np.arange(keys, dtype=np.float32)[None, None, :, None] / keys
                            + np.array([0, 1], dtype=np.float32)[None, :, None, None], v.shape).copy()
    tensors = {"q": q, "k": k, "v": v}
    row, column = np.arange(length)[:, None], np.arange(keys)[None, :]
    mask_type = None
    if case_id in {"S2", "S6"}:
        tensors["mask"] = ((column <= keys - length + row) if case_id == "S6" else ((column + row) % 3 != 2))[None, None]
        mask_type = "bool"
    if case_id == "S3":
        tensors["mask"] = np.array([0., -2., -np.inf], dtype=np.float32)[(column + row) % 3][None, None]
        mask_type = "float"
    return tensors, {"scale": 8 ** -.5, "dropout_p": 0., "enable_gqa": case_id == "S8",
                     "is_causal": case_id in {"S4", "S5"}, "mask_type": mask_type, "requested_backend": "auto"}


def quantize(values, case_id, dtype):
    import torch

    tensors = {key: torch.from_numpy(value).to(getattr(torch, dtype) if value.dtype != np.bool_ else torch.bool)
               for key, value in values.items()}
    if case_id == "G2":
        for name in ("a", "b"):
            tensors[name] = tensors[name].T.contiguous().T
    return tensors


def invoke(case_id, x, args):
    import torch
    from torch.nn import functional as f

    if case_id.startswith("G"):
        return torch.addmm(x["c"], x["a"], x["b"], alpha=args["alpha"], beta=args["beta"])
    if case_id.startswith("R"):
        return f.rms_norm(x["x"], args["normalized_shape"], x["weight"], args["eps"])
    kwargs = dict(attn_mask=x.get("mask"), dropout_p=args["dropout_p"], scale=args["scale"], is_causal=args["is_causal"])
    if args["enable_gqa"]:
        kwargs["enable_gqa"] = True
    return f.scaled_dot_product_attention(x["q"], x["k"], x["v"], **kwargs)
