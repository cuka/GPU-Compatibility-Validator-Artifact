"""Load and validate the native extension, then describe its outputs to FakeTensor."""

import os
from pathlib import Path

from .contracts import AuditError, file_digest


NATIVE_ROLES = {"fp64_scan": "compare", "fp64_summarize": "reduce", "fp64_scaled_partial": "reduce",
                "fp64_finish": "reduce", "fp64_empty": "initialize", "fp64_probe": "fp64_probe",
                **{f"stage_{name}": f"stage_{name}" for name in "abcdef"}}


def load_native(expected_sha256=None):
    import torch

    directory = Path(__file__).resolve().parent
    candidates = sorted(directory.glob("compute_audit_native.so"))
    configured = os.environ.get("COMPUTE_AUDIT_NATIVE_LIBRARY")
    if configured:
        candidates = [Path(configured).resolve()]
    if len(candidates) != 1 or not candidates[0].is_file():
        raise AuditError("NATIVE_EXTENSION_UNAVAILABLE")
    path = candidates[0]
    checksum = file_digest(path)
    if expected_sha256 is not None and checksum != expected_sha256:
        raise AuditError("NATIVE_EXTENSION_MISMATCH")
    torch.ops.load_library(str(path))
    ops = torch.ops.compute_audit
    if ops._validator_abi() != "3.1":
        raise AuditError("NATIVE_ABI_MISMATCH")
    if not getattr(load_native, "registered", False):
        @torch.library.register_fake("compute_audit::validate_compute")
        def fake(actual, reference, challenge, parameters, context, nonce, atol, rtol, relative_floor):
            return (actual.new_empty((4,)), challenge.new_empty((9,)), challenge.new_empty(()),
                    challenge.new_empty(challenge.shape), challenge.new_empty(()), nonce.new_empty((32,)))

        @torch.library.register_fake("compute_audit::_validate_sample")
        def fake_sample(challenge, parameters, context, nonce, group, item):
            shape = challenge.shape if group == 6 or group == 5 and item >= 5 else (0,)
            return challenge.new_empty(shape), challenge.new_empty(()), nonce.new_empty((32,))

        load_native.registered = True
    return ops, {"native_sha256": checksum, "native_path": str(path), "validator_abi": "3.1"}


def capture_trace(torch, device, operation):
    """Run an invocation and keep its full profiler trace in memory."""
    import tempfile
    import time

    torch.cuda.synchronize(device)
    before = time.perf_counter_ns()
    if torch.profiler.ProfilerActivity.CUDA not in torch.profiler.supported_activities():
        result = operation()
        torch.cuda.synchronize(device)
        return result, [], (time.perf_counter_ns() - before) / 1e6
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as profile:
        result = operation()
        torch.cuda.synchronize(device)
    from .contracts import load

    with tempfile.TemporaryDirectory() as scratch:
        trace = Path(scratch) / "trace.json"
        profile.export_chrome_trace(str(trace))
        events = load(trace).get("traceEvents", [])
    return result, events, (time.perf_counter_ns() - before) / 1e6


def capture(device, operation, native=False, *, binding=None):
    """Project observed kernels onto the selected device without publishing the raw trace."""
    import torch

    result, events, elapsed = capture_trace(torch, device, operation)
    calibration = binding.get("kineto_calibration") if binding is not None else None
    if binding is not None and calibration is None:
        return result, [], elapsed, events
    raw_device = device.index if calibration is None else calibration["raw_device"]
    result_events = []
    for event in events:
        if not isinstance(event, dict) or event.get("cat") != "kernel" or event.get("ph") != "X":
            continue
        args, name = event.get("args"), event.get("name")
        if not isinstance(args, dict) or type(args.get("device")) is not int or args["device"] != raw_device or not isinstance(name, str):
            continue
        start, duration = event.get("ts"), event.get("dur")
        if any(type(value) not in (int, float) or not 0 <= value <= 1e20 for value in (start, duration)):
            continue
        role = next((role for kernel, role in NATIVE_ROLES.items() if f"compute_audit_{kernel}" in name), None) if native else "operator"
        stream = args.get("stream")
        if role and type(stream) is int and stream >= 0:
            activity = dict(device=device.index, stream=stream, role=role, start_us=start, duration_us=duration, source="kineto")
            if calibration is not None:
                activity["raw_device"] = raw_device
            result_events.append(activity)
    return result, result_events, elapsed, events


