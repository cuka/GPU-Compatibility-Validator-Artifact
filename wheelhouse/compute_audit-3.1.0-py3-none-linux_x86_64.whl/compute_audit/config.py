"""Published profiles and immutable case expansion."""

from importlib.resources import files

from .contracts import AuditError, canonical, digest, load, parse


DTYPES = ("float32", "bfloat16", "float16")
GENERAL = {"GEMM": tuple(f"G{i}" for i in range(1, 5)), "RMSNorm": tuple(f"R{i}" for i in range(1, 4)),
           "SDPA": tuple(f"S{i}" for i in range(1, 9))}
SELFTESTS = tuple(f"{prefix}{i}" for prefix in ("C", "V") for i in range(1, 7))
DIAGNOSTIC_ITEMS = (2, 4, 3, 4, 11, 2)


def normalize_profile(raw):
    defaults = parse(files("compute_audit").joinpath("data/defaults.json").read_bytes())
    if not isinstance(raw, dict) or raw.get("schema_version") != "3.0":
        raise AuditError("PROFILE_SCHEMA_INVALID")
    profile = defaults | raw
    scope = profile.get("scope")
    if scope not in {"smoke", "conformance", "acceptance"} or not profile.get("profile_id"):
        raise AuditError("PROFILE_SCOPE_INVALID")
    if profile.get("profile_status") not in {"development", "draft", "released"}:
        raise AuditError("PROFILE_STATUS_INVALID")
    skip_device_fp64 = profile.get("skip_device_fp64", False)
    if type(skip_device_fp64) is not bool:
        raise AuditError("PROFILE_FP64_POLICY_INVALID")
    if skip_device_fp64 and (scope != "conformance" or profile["profile_status"] != "development"):
        raise AuditError("PROFILE_FP64_SKIP_REQUIRES_DIAGNOSTIC_MODE")
    if profile["execution_variant"] != "eager" or profile["parallel_devices"] != 1:
        raise AuditError("PROFILE_EXECUTION_UNSUPPORTED")
    if profile["execution_mode"] != ("cpu_reference" if scope == "smoke" else "real"):
        raise AuditError("PROFILE_EXECUTION_INVALID")
    dtypes = profile["required_dtypes"] + profile["enabled_optional_dtypes"]
    if not dtypes or set(dtypes) - set(DTYPES) or len(set(dtypes)) != len(dtypes):
        raise AuditError("PROFILE_DTYPES_INVALID")
    if set(profile["optional_cases"]) - set(GENERAL["SDPA"]):
        raise AuditError("PROFILE_OPTIONAL_CASES_INVALID")
    for key, minimum in {"timed_iterations": 1, "minimum_valid_timed_samples": 1, "warmup_iterations": 0, "seed": 0,
                         "max_case_seconds": 1, "max_device_seconds": 1, "challenge_length": 2,
                         "reference_block_query_rows": 1, "max_host_working_bytes": 1,
                         "max_device_working_bytes": 1}.items():
        if type(profile[key]) is not int or profile[key] < minimum:
            raise AuditError(f"PROFILE_INVALID: {key}")
    if (profile["minimum_valid_timed_samples"] != profile["timed_iterations"]
            or profile["timed_sample_exclusion_policy"] != "none"
            or profile["timed_output_verification"] != "all" or profile["verification_scope"] != "full"
            or not 0 < profile["max_device_free_memory_fraction"] <= 1 or profile["relative_floor"] <= 0
            or profile["rmsnorm_eps"] <= 0 or profile["sdpa_dropout_p"] != 0
            or profile["performance_gate"]["enabled"]):
        raise AuditError("PROFILE_POLICY_UNSUPPORTED")
    return profile


def profile_from(path):
    return normalize_profile(load(path))


def tolerance(profile, case):
    dtype = case["dtype"]
    if dtype is None:
        return (0.0, 0.0)
    result = profile["tolerance"][dtype] | profile["operator_tolerance"].get(case["operator"], {}).get(dtype, {})
    result |= profile["case_tolerance"].get(case["case_id"], {}).get(dtype, {})
    if any(type(result[key]) not in (int, float) or not 0 <= result[key] < float("inf") for key in ("atol", "rtol")):
        raise AuditError("PROFILE_TOLERANCE_INVALID")
    return result["atol"], result["rtol"]


def build_cases(targets, profile, *, selftest=False, legacy_vectors=None):
    rows = []
    for target in targets:
        for case_id in SELFTESTS:
            if profile.get("skip_device_fp64") and case_id.startswith("V"):
                continue
            vectors = (("initial", "core", "runtime_derived"),)
            if case_id.startswith("C"):
                group = int(case_id[1:])
                vectors = tuple((f"check-{item}", "core" if group == 1 else "diagnostic", "runtime_derived")
                                for item in range(DIAGNOSTIC_ITEMS[group - 1]))
                if legacy_vectors is not None:
                    vectors = legacy_vectors[case_id]
            rows.append((target["target_id"], "Validate Compute", case_id, None, True, vectors))
        if selftest:
            continue
        for operator, cases in GENERAL.items():
            for case_id in cases:
                for dtype in profile["required_dtypes"] + profile["enabled_optional_dtypes"]:
                    vectors = tuple((sample, "core", "runtime_derived") for sample in
                                    ("initial", *(f"sample-{i}" for i in range(profile["timed_iterations"]))))
                    required = dtype in profile["required_dtypes"] and case_id not in profile["optional_cases"]
                    rows.append((target["target_id"], operator, case_id, dtype, required, vectors))
    return [dict(target_id=target_id, operator=operator, case_id=case_id, dtype=dtype, required=required,
                 execution_variant=profile["execution_variant"], record_id=f"{target_id}.{case_id}.{dtype or 'selftest'}",
                 invocations=[dict(sample_id=s, invocation_type=t, input_mode=m) for s, t, m in vectors])
            for target_id, operator, case_id, dtype, required, vectors in rows]


def catalog_digest(*, legacy_vectors=None):
    catalog = {"operators": GENERAL, "selftests": SELFTESTS}
    if legacy_vectors is not None:
        catalog["subvectors"] = legacy_vectors
    else:
        catalog.update(diagnostic_items=DIAGNOSTIC_ITEMS, validator_abi="3.1")
    return digest(canonical(catalog))
